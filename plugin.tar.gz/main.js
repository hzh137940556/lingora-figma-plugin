"use strict";
(() => {
  var __defProp = Object.defineProperty, __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty, __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: !0, configurable: !0, writable: !0, value }) : obj[key] = value, __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      __hasOwnProp.call(b, prop) && __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b))
        __propIsEnum.call(b, prop) && __defNormalProp(a, prop, b[prop]);
    return a;
  }, __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key != "symbol" ? key + "" : key, value);

  // src/shared/contracts.ts
  var DEFAULT_SETTINGS = {
    serverUrl: "",
    projectId: "",
    branchId: "",
    namespace: "",
    keyTemplate: "{artboard}.{elementName}",
    keyCase: "snake",
    prefillKeys: !1,
    showIgnored: !1,
    ignore: { numbers: !0, formattedNumbers: !0, emoji: !0, hiddenLayers: !0, hiddenChildren: !1, prefix: "_" },
    uploadScreenshots: !0,
    tags: []
  };

  // src/core/validation.ts
  function isObject(value) {
    return typeof value == "object" && value !== null && !Array.isArray(value);
  }
  function isSessionNonce(value) {
    return typeof value == "string" && /^[0-9a-f]{32}$/.test(value);
  }
  function isFigmaFileKey(value) {
    return typeof value == "string" && /^[A-Za-z0-9]{1,255}$/.test(value);
  }
  function isText(value) {
    return typeof value == "string" && value.length <= 1e5;
  }
  function isStrings(value) {
    return Array.isArray(value) && value.length <= 1e4 && value.every(isText);
  }
  function isTarget(value) {
    return isObject(value) && isText(value.serverUrl) && isText(value.projectId) && isText(value.branchId);
  }
  function isDeviceConnection(value) {
    if (!isObject(value) || typeof value.serverUrl != "string" || value.serverUrl.length > 2048 || typeof value.projectId != "string" || typeof value.apiKey != "string") return !1;
    let origin = /^(https?):\/\/([a-z0-9._-]+|\[[0-9a-f:]+\])(?::(\d{1,5}))?$/i.exec(value.serverUrl);
    return !origin || origin[3] !== void 0 && Number(origin[3]) > 65535 || origin[1].toLowerCase() === "http" && !["localhost", "127.0.0.1", "[::1]"].includes(origin[2].toLowerCase()) ? !1 : /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value.projectId) && value.apiKey.length > 0 && value.apiKey.length <= 4096 && !/[\u0000-\u0020\u007f]/.test(value.apiKey);
  }
  function isPreviewValues(value) {
    return isObject(value) && Object.keys(value).length <= 200 && Object.values(value).every((item) => isText(item) || typeof item == "number" && Number.isFinite(item));
  }
  function isBinding(value) {
    return isObject(value) && isTarget(value) && isText(value.keyId) && isText(value.keyName) && isText(value.namespace) && isObject(value.baselines) && Object.values(value.baselines).every((item) => item === null || isText(item));
  }
  function isNodeData(value) {
    if (!isObject(value) || !isText(value.language) || !isText(value.keyName) || !isText(value.namespace) || !(value.binding === null || isBinding(value.binding)) || value.keyNameCleared !== void 0 && typeof value.keyNameCleared != "boolean" || value.manuallyIgnored !== void 0 && typeof value.manuallyIgnored != "boolean") return !1;
    let advanced = value.advanced;
    return advanced === null || isObject(advanced) && isText(advanced.rawText) && isText(advanced.renderedText) && isPreviewValues(advanced.values) && (advanced.styleFlags === void 0 || isObject(advanced.styleFlags) && typeof advanced.styleFlags.font == "boolean" && typeof advanced.styleFlags.underline == "boolean");
  }
  function isIgnore(value) {
    return isObject(value) && typeof value.numbers == "boolean" && typeof value.formattedNumbers == "boolean" && (value.emoji === void 0 || typeof value.emoji == "boolean") && typeof value.hiddenLayers == "boolean" && typeof value.hiddenChildren == "boolean" && isText(value.prefix);
  }
  function isSettings(value) {
    return isObject(value) && isTarget(value) && isText(value.namespace) && isText(value.keyTemplate) && typeof value.keyCase == "string" && ["original", "snake", "capitalSnake", "camel", "pascal", "compact"].includes(value.keyCase) && typeof value.prefillKeys == "boolean" && (value.showIgnored === void 0 || typeof value.showIgnored == "boolean") && isIgnore(value.ignore) && typeof value.uploadScreenshots == "boolean" && isStrings(value.tags);
  }
  function isFont(value) {
    return isObject(value) && isText(value.family) && value.family.length > 0 && isText(value.style) && value.style.length > 0;
  }
  function isFontPolicy(value) {
    return isObject(value) && (value.kind === "skip" || value.kind === "replace" && isFont(value.font));
  }
  function isTextUpdate(value) {
    return isObject(value) && isText(value.nodeId) && isText(value.expectedCharacters) && isText(value.rawText) && isPreviewValues(value.values) && isRenderedText(value.rendered) && (value.binding === void 0 || value.binding === null || isBinding(value.binding));
  }
  function isRenderedText(value) {
    if (!isObject(value) || !isText(value.text) || typeof value.advanced != "boolean" || !Array.isArray(value.runs) || value.runs.length > 1e4) return !1;
    let end = 0;
    for (let item of value.runs) {
      if (!isObject(item) || typeof item.start != "number" || typeof item.end != "number" || !Number.isInteger(item.start) || !Number.isInteger(item.end) || item.start !== end || item.end <= item.start || item.end > value.text.length || typeof item.bold != "boolean" || typeof item.italic != "boolean" || typeof item.underline != "boolean") return !1;
      end = item.end;
    }
    return end === value.text.length;
  }
  function isPageCopy(value) {
    return isObject(value) && (value.kind === "language" || value.kind === "keys") && isText(value.sourcePageId) && isText(value.sourceFingerprint) && isText(value.language) && isText(value.createdAt) && (value.target === void 0 || isTarget(value.target)) && (value.contentFingerprint === void 0 || isText(value.contentFingerprint));
  }
  function isCopyReplacement(value) {
    return isObject(value) && isText(value.pageId) && isText(value.name) && isText(value.fingerprint) && value.fingerprint.length > 0 && typeof value.modified == "boolean";
  }
  function isCopyRequest(value) {
    return isObject(value) && isText(value.sourcePageId) && isText(value.sourceFingerprint) && Array.isArray(value.replacements) && value.replacements.length <= 100 && value.replacements.every(isCopyReplacement) && new Set(value.replacements.map((item) => item.pageId)).size === value.replacements.length && (value.kind === "language" || value.kind === "keys") && isText(value.language) && isTarget(value.target) && isFontPolicy(value.fontPolicy) && Array.isArray(value.translations) && value.translations.length <= 1e4 && value.translations.every((item) => isObject(item) && isText(item.nodeId) && isText(item.keyId) && isText(item.keyName) && isText(item.namespace) && isText(item.rawText) && isPreviewValues(item.values) && isRenderedText(item.rendered));
  }
  function isMainRequest(value) {
    if (!isObject(value) || !isSessionNonce(value.sessionNonce) || !isText(value.requestId) || value.requestId.length > 200) return !1;
    switch (value.type) {
      case "scan":
        return (value.scope === void 0 || value.scope === "selection" || value.scope === "page") && (value.includeFingerprint === void 0 || typeof value.includeFingerprint == "boolean");
      case "save-settings":
        return isSettings(value.settings);
      case "load-device-connection":
      case "forget-device-connection":
        return !0;
      case "save-device-connection":
        return isDeviceConnection(value.connection);
      case "set-page-language":
        return isText(value.pageId) && isText(value.language);
      case "set-node-ignored":
        return isText(value.pageId) && typeof value.ignored == "boolean" && Array.isArray(value.items) && value.items.length > 0 && value.items.length <= 1e4 && value.items.every((item) => isObject(item) && isText(item.nodeId) && isText(item.expectedCharacters));
      case "save-nodes":
        return isText(value.pageId) && Array.isArray(value.items) && value.items.length <= 1e4 && value.items.every((item) => isObject(item) && isText(item.nodeId) && isText(item.expectedCharacters) && isNodeData(item.data));
      case "font-check":
        return isText(value.pageId) && value.pageId.length > 0 && isStrings(value.nodeIds);
      case "focus":
        return isStrings(value.nodeIds);
      case "list-fonts":
        return !0;
      case "apply-text":
        return isText(value.pageId) && isText(value.language) && isFontPolicy(value.fontPolicy) && Array.isArray(value.items) && value.items.length <= 1e4 && value.items.every(isTextUpdate);
      case "screenshots":
        return isText(value.pageId) && isStrings(value.nodeIds);
      case "preview-copy":
        return isText(value.sourcePageId) && (value.kind === "keys" || value.kind === "language") && isText(value.language) && isTarget(value.target);
      case "create-copy":
        return isCopyRequest(value.copy);
      case "rebuild-copy":
        return isText(value.pageId) && isCopyRequest(value.copy);
      case "open-page":
        return isText(value.pageId);
      case "open-key":
        return isTarget(value.target) && isText(value.keyName) && value.keyName.length <= 2e3;
      case "resize":
        return typeof value.width == "number" && Number.isFinite(value.width) && typeof value.height == "number" && Number.isFinite(value.height) && (value.measure === void 0 || typeof value.measure == "boolean");
      default:
        return !1;
    }
  }

  // src/core/binding.ts
  function emptyNodeData() {
    return { language: "", keyName: "", namespace: "", binding: null, advanced: null };
  }
  function cleanBinding(binding) {
    return { serverUrl: binding.serverUrl, projectId: binding.projectId, branchId: binding.branchId, keyId: binding.keyId, keyName: binding.keyName, namespace: binding.namespace, baselines: __spreadValues({}, binding.baselines) };
  }
  function copyNodeData(data) {
    return __spreadValues(__spreadValues({
      language: data.language,
      keyName: data.keyName,
      namespace: data.namespace,
      binding: data.binding ? cleanBinding(data.binding) : null,
      advanced: data.advanced ? __spreadValues({ rawText: data.advanced.rawText, renderedText: data.advanced.renderedText, values: __spreadValues({}, data.advanced.values) }, data.advanced.styleFlags ? { styleFlags: { font: data.advanced.styleFlags.font, underline: data.advanced.styleFlags.underline } } : {}) : null
    }, data.manuallyIgnored ? { manuallyIgnored: !0 } : {}), !data.keyName && !data.binding && data.keyNameCleared ? { keyNameCleared: !0 } : {});
  }
  function readNodeData(raw) {
    try {
      let value = JSON.parse(raw);
      return isNodeData(value) ? copyNodeData(value) : emptyNodeData();
    } catch (e) {
      return emptyNodeData();
    }
  }
  function sameTarget(left, right) {
    return left.serverUrl.replace(/\/$/, "") === right.serverUrl.replace(/\/$/, "") && left.projectId === right.projectId && left.branchId === right.branchId;
  }
  function bindingFingerprint(nodes) {
    let serialized = JSON.stringify(nodes.map((node) => [node.id, node.keyName, node.namespace, node.binding ? [node.binding.serverUrl, node.binding.projectId, node.binding.branchId, node.binding.keyId, node.binding.keyName, node.binding.namespace] : null]).sort((a, b) => String(a[0]) < String(b[0]) ? -1 : String(a[0]) > String(b[0]) ? 1 : 0)), hash = 2166136261;
    for (let index = 0; index < serialized.length; index += 1) hash = Math.imul(hash ^ serialized.charCodeAt(index), 16777619);
    return `${nodes.length}:${(hash >>> 0).toString(16)}`;
  }

  // src/core/naming.ts
  function formatKeyPart(value, style) {
    if (style === "original") return value.trim();
    let lower = value.trim().replace(/([a-z0-9])([A-Z])/g, "$1 $2").split(/[^\p{L}\p{N}]+/u).filter(Boolean).map((word) => word.toLowerCase()), upperFirst = (word) => word.charAt(0).toUpperCase() + word.slice(1);
    switch (style) {
      case "snake":
        return lower.join("_");
      case "capitalSnake":
        return upperFirst(lower.join("_"));
      case "camel":
        return lower.map((word, index) => index === 0 ? word : upperFirst(word)).join("");
      case "pascal":
        return lower.map(upperFirst).join("");
      case "compact":
        return lower.join("");
    }
  }
  function generateKey(template, fields, style) {
    let known = __spreadValues({}, fields);
    return template.replace(/([.:/_-]?)\{(\w+)\}([.:/_-]?)/g, (_match, before, key, after) => {
      var _a;
      let value = formatKeyPart((_a = known[key]) != null ? _a : "", style);
      return value ? before + value + after : before && after ? before : "";
    }).replace(/^[.:/_-]+|[.:/_-]+$/g, "").trim();
  }
  var EMOJI_BASE = new RegExp("(?:\\p{Emoji_Modifier_Base}\\uFE0F?\\p{Emoji_Modifier}|(?![\\p{Regional_Indicator}\\p{Emoji_Modifier}])\\p{Emoji_Presentation}\\uFE0F?|(?=[^0-9#*])(?!\\p{Emoji_Presentation})\\p{Emoji}\\uFE0F)", "u"), EMOJI_SEQUENCE = `(?:\\p{Regional_Indicator}{2}|[0-9#*]\\uFE0F?\\u20E3|${EMOJI_BASE.source}(?:[\\u{E0020}-\\u{E007E}]+\\u{E007F})?(?:\\u200D${EMOJI_BASE.source})*)`, PURE_EMOJI = new RegExp(`^(?:${EMOJI_SEQUENCE}\\s*)+$`, "u");
  function shouldIgnoreText(text, name, visible, hiddenAncestor, settings2) {
    var _a;
    let trimmed = text.trim();
    return !trimmed || settings2.prefix && name.startsWith(settings2.prefix) || settings2.hiddenLayers && (!visible || settings2.hiddenChildren && hiddenAncestor) || ((_a = settings2.emoji) == null || _a) && PURE_EMOJI.test(trimmed) ? !0 : settings2.numbers ? /^\d+$/.test(trimmed) ? !0 : settings2.formattedNumbers && /^[+-]?(?:\d{1,3}(?:[ ,.\u00a0]\d{3})+|\d+)(?:[.,]\d+)?%?$/.test(trimmed) : !1;
  }

  // src/core/window.ts
  function clampPluginWindow(requested, available) {
    var _a, _b;
    let width = Number.isFinite(requested.width) ? Math.round(requested.width) : 500, height = Number.isFinite(requested.height) ? Math.round(requested.height) : 600;
    return {
      width: clampAxis(width, 500, (_a = available == null ? void 0 : available.width) != null ? _a : null),
      height: clampAxis(height, 600, (_b = available == null ? void 0 : available.height) != null ? _b : null)
    };
  }
  function pluginWindowCanvasPoint(current, targetWindow, zoom) {
    return !Number.isFinite(zoom) || zoom <= 0 || !finitePoint(current.windowSpace) || !finitePoint(current.canvasSpace) || !finitePoint(targetWindow) ? null : {
      x: current.canvasSpace.x + (targetWindow.x - current.windowSpace.x) / zoom,
      y: current.canvasSpace.y + (targetWindow.y - current.windowSpace.y) / zoom
    };
  }
  function balancePluginWindow(frame, gap) {
    let even = Math.max(0, Math.min(
      Math.floor(gap),
      Math.floor((frame.width - 500) / 2),
      Math.floor((frame.height - 600) / 2)
    ));
    return {
      origin: { x: Math.round(frame.x + even), y: Math.round(frame.y + even) },
      size: { width: Math.round(frame.width - even * 2), height: Math.round(frame.height - even * 2) }
    };
  }
  function pluginWindowMovedToward(before, after, targetWindow) {
    if (!after || !finitePoint(after.windowSpace) || !finitePoint(targetWindow)) return !0;
    if (!before || !finitePoint(before.windowSpace)) return !1;
    let next = pointDistance(after.windowSpace, targetWindow);
    return next <= 1 || next + 0.5 < pointDistance(before.windowSpace, targetWindow);
  }
  function readResizeLimit(message) {
    let width = axisLimit(message, "width"), height = axisLimit(message, "height"), pair = message.match(/(?:<=|at most|maximum|不超过)\s*(\d+)\s*[x×]\s*(\d+)/i), limit = { width: width != null ? width : pair ? Number(pair[1]) : null, height: height != null ? height : pair ? Number(pair[2]) : null };
    return limit.width === null && limit.height === null ? null : limit;
  }
  function fitPluginWindow(requested, resize, cause) {
    let desired = clampPluginWindow(requested, null), parsed = readResizeLimit(cause instanceof Error ? cause.message : "");
    if (parsed) {
      let fitted = clampPluginWindow(desired, parsed);
      try {
        return resize(fitted), fitted;
      } catch (error) {
        return shrinkPluginWindow(fitted, resize, error);
      }
    }
    return shrinkPluginWindow(desired, resize);
  }
  function finitePoint(point) {
    return Number.isFinite(point.x) && Number.isFinite(point.y);
  }
  function pointDistance(from, to) {
    return Math.hypot(from.x - to.x, from.y - to.y);
  }
  function clampAxis(value, minimum, maximum) {
    let lower = Math.max(value, minimum);
    return maximum === null ? lower : Math.min(lower, Math.max(maximum, minimum));
  }
  function axisLimit(message, axis) {
    let other = axis === "width" ? "height" : "width", match = message.match(new RegExp(`${axis}\\s*((?:(?!${other})[\\s\\S]){0,96})`, "i"));
    if (!match) return null;
    let clause = match[1].split(/\b(?:got|received|requested|actual|provided)\b/i)[0];
    if (!/(?:<=|>=|at most|between|maximum|less than|不超过|不大于)/i.test(clause)) return null;
    let numbers = [...clause.matchAll(/\d+/g)].map((item) => Number(item[0]));
    return numbers.length === 0 ? null : Math.max(...numbers);
  }
  function shrinkPluginWindow(requested, resize, cause) {
    var _a, _b;
    try {
      resize({ width: 500, height: 600 });
    } catch (e) {
      throw new Error("\u63D2\u4EF6\u7A97\u53E3\u65E0\u6CD5\u4FDD\u6301\u9ED8\u8BA4\u5C3A\u5BF8\uFF0C\u8BF7\u589E\u5927 Figma \u7A97\u53E3\u540E\u91CD\u8BD5\u3002");
    }
    let parsed = readResizeLimit(cause instanceof Error ? cause.message : ""), width = fitAxis((_a = parsed == null ? void 0 : parsed.width) != null ? _a : requested.width, 500, (value) => resize({ width: value, height: 600 })), height = fitAxis((_b = parsed == null ? void 0 : parsed.height) != null ? _b : requested.height, 600, (value) => resize({ width, height: value })), fitted = { width, height };
    return resize(fitted), fitted;
  }
  function fitAxis(maximum, minimum, apply) {
    let best = minimum, low = minimum, high = Math.max(minimum, Math.round(maximum));
    for (; low <= high; ) {
      let mid = Math.floor((low + high) / 2);
      try {
        apply(mid), best = mid, low = mid + 1;
      } catch (e) {
        high = mid - 1;
      }
    }
    return best;
  }

  // src/host/document.ts
  var NODE_DATA = "lingora.node.v1", PAGE_LANGUAGE = "lingora.language.v1", PAGE_COPY = "lingora.copy.v1";
  function requireWrite() {
    if (figma.editorType !== "figma") throw new Error("Dev Mode \u53EA\u80FD\u67E5\u770B\u753B\u5E03\uFF1B\u8BF7\u5207\u6362\u5230\u8BBE\u8BA1\u6A21\u5F0F\u540E\u64CD\u4F5C\u3002");
  }
  function pageCopy(page) {
    try {
      let value = JSON.parse(page.getPluginData(PAGE_COPY));
      return isPageCopy(value) ? __spreadValues(__spreadValues({ kind: value.kind, sourcePageId: value.sourcePageId, sourceFingerprint: value.sourceFingerprint, language: value.language, createdAt: value.createdAt }, value.target ? { target: { serverUrl: value.target.serverUrl, projectId: value.target.projectId, branchId: value.target.branchId } } : {}), value.contentFingerprint ? { contentFingerprint: value.contentFingerprint } : {}) : null;
    } catch (e) {
      return null;
    }
  }
  function pageRecord(page) {
    return { id: page.id, name: page.name, language: page.getPluginData(PAGE_LANGUAGE), copy: pageCopy(page) };
  }
  async function getPage(pageId) {
    let node = await figma.getNodeByIdAsync(pageId);
    if (!node || node.type !== "PAGE") throw new Error("\u76EE\u6807\u9875\u9762\u5DF2\u5220\u9664\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u9875\u9762\u3002");
    return node.id !== figma.currentPage.id && await node.loadAsync(), node;
  }
  async function getCurrentPage(pageId) {
    if (figma.currentPage.id !== pageId) throw new Error("\u5F53\u524D\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u540E\u64CD\u4F5C\u3002");
    let page = await getPage(pageId);
    if (figma.currentPage.id !== pageId) throw new Error("\u52A0\u8F7D\u671F\u95F4\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
    return page;
  }
  function belongsToPage(node, page) {
    let current = node;
    for (; current && current.type !== "PAGE"; ) current = current.parent;
    return (current == null ? void 0 : current.id) === page.id;
  }
  async function getText(page, nodeId) {
    let node = await figma.getNodeByIdAsync(nodeId);
    if (!node || node.type !== "TEXT" || node.removed) throw new NodeFailure("missing-node", "\u6587\u672C\u56FE\u5C42\u5DF2\u5220\u9664\u6216\u4E0D\u518D\u662F\u6587\u672C\u3002");
    if (!belongsToPage(node, page)) throw new NodeFailure("wrong-page", "\u6587\u672C\u4E0D\u5C5E\u4E8E\u672C\u6B21\u64CD\u4F5C\u7684\u9875\u9762\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF\u3002");
    return node;
  }
  var NodeFailure = class extends Error {
    /** 保存节点错误码与中文提示。 */
    constructor(code, message) {
      super(message);
      __publicField(this, "code", code);
    }
  };
  function issue(nodeId, error, fallback = "\u8BE5\u6587\u672C\u5904\u7406\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF\u540E\u91CD\u8BD5\u3002") {
    return error instanceof NodeFailure ? { nodeId, code: error.code, message: error.message } : { nodeId, code: "unknown", message: fallback };
  }
  function textNodes(roots) {
    let result = [], seen = /* @__PURE__ */ new Set();
    function visit(node) {
      if (!seen.has(node.id)) {
        if (seen.add(node.id), node.type === "TEXT") result.push(node);
        else if ("children" in node) for (let child of node.children) visit(child);
      }
    }
    for (let root of roots) visit(root);
    return result;
  }
  function clonedTexts(source, copy) {
    let pairs = /* @__PURE__ */ new Map();
    function pair(originals, copies) {
      for (let index = 0; index < originals.length; index += 1) {
        let original = originals[index], cloned = copies[index];
        !cloned || original.name !== cloned.name || (original.type === "TEXT" && cloned.type === "TEXT" && original.characters === cloned.characters && original.getPluginData(NODE_DATA) === cloned.getPluginData(NODE_DATA) ? pairs.set(original.id, cloned) : "children" in original && "children" in cloned && pair(original.children, cloned.children));
      }
    }
    return pair(source.children, copy.children), pairs;
  }
  function hiddenParent(node) {
    let parent = node.parent;
    for (; parent && parent.type !== "PAGE" && parent.type !== "DOCUMENT"; ) {
      if ("visible" in parent && !parent.visible) return !0;
      parent = parent.parent;
    }
    return !1;
  }
  function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (!isObject(value)) return value;
    let result = {};
    for (let key of Object.keys(value).sort())
      ["pluginData", "sharedPluginData", "lastModified"].includes(key) || (result[key] = canonical(value[key]));
    return result;
  }
  async function pageFingerprint(page) {
    let exported = await page.exportAsync({ format: "JSON_REST_V1" }), text = JSON.stringify([canonical(exported), page.getPluginData(PAGE_LANGUAGE), textNodes(page.children).map((node) => [node.id, node.getPluginData(NODE_DATA)])]), left = 2166136261, right = 5381;
    for (let index = 0; index < text.length; index += 1)
      left = Math.imul(left ^ text.charCodeAt(index), 16777619), right = Math.imul(right, 33) ^ text.charCodeAt(index);
    return `${text.length}:${(left >>> 0).toString(16)}:${(right >>> 0).toString(16)}`;
  }
  function writeData(node, data) {
    let cleaned = copyNodeData(data);
    cleaned.binding && (cleaned.keyName = cleaned.binding.keyName, cleaned.namespace = cleaned.binding.namespace);
    let serialized = JSON.stringify(cleaned);
    if (serialized.length * 3 > 9e4) throw new NodeFailure("invalid-data", "\u8282\u70B9\u5173\u8054\u6216\u9AD8\u7EA7\u6587\u672C\u8FC7\u5927\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u5230 Figma \u56FE\u5C42\u3002");
    node.setPluginData(NODE_DATA, serialized);
  }
  function validateBinding(data, config) {
    if (data.binding && (!sameTarget(data.binding, config) || !data.binding.keyId)) throw new NodeFailure("invalid-data", "\u5173\u8054\u76EE\u6807\u4E0E\u5F53\u524D\u670D\u52A1\u3001\u9879\u76EE\u6216\u5206\u652F\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002");
  }
  function expectText(node, expected) {
    if (node.characters !== expected) throw new NodeFailure("stale-node", "\u753B\u5E03\u6587\u672C\u5DF2\u5728\u9884\u89C8\u540E\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
  }

  // node_modules/@formatjs/icu-skeleton-parser/index.js
  var DATE_TIME_REGEX = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
  function parseDateTimeSkeleton(skeleton) {
    let result = {};
    return skeleton.replace(DATE_TIME_REGEX, (match) => {
      let len = match.length;
      switch (match[0]) {
        case "G":
          result.era = len === 4 ? "long" : len === 5 ? "narrow" : "short";
          break;
        case "y":
          result.year = len === 2 ? "2-digit" : "numeric";
          break;
        case "Y":
        case "u":
        case "U":
        case "r":
          throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
        case "q":
        case "Q":
          throw new RangeError("`q/Q` (quarter) patterns are not supported");
        case "M":
        case "L":
          result.month = [
            "numeric",
            "2-digit",
            "short",
            "long",
            "narrow"
          ][len - 1];
          break;
        case "w":
        case "W":
          throw new RangeError("`w/W` (week) patterns are not supported");
        case "d":
          result.day = ["numeric", "2-digit"][len - 1];
          break;
        case "D":
        case "F":
        case "g":
          throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
        case "E":
          result.weekday = len === 4 ? "long" : len === 5 ? "narrow" : "short";
          break;
        case "e":
          if (len < 4) throw new RangeError("`e..eee` (weekday) patterns are not supported");
          result.weekday = [
            "short",
            "long",
            "narrow",
            "short"
          ][len - 3];
          break;
        case "c":
          if (len < 4) throw new RangeError("`c..ccc` (weekday) patterns are not supported");
          result.weekday = [
            "short",
            "long",
            "narrow",
            "short"
          ][len - 3];
          break;
        case "a":
          result.hour12 = !0;
          break;
        case "b":
        case "B":
          throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
        case "h":
          result.hourCycle = "h12", result.hour = ["numeric", "2-digit"][len - 1];
          break;
        case "H":
          result.hourCycle = "h23", result.hour = ["numeric", "2-digit"][len - 1];
          break;
        case "K":
          result.hourCycle = "h11", result.hour = ["numeric", "2-digit"][len - 1];
          break;
        case "k":
          result.hourCycle = "h24", result.hour = ["numeric", "2-digit"][len - 1];
          break;
        case "j":
        case "J":
        case "C":
          throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
        case "m":
          result.minute = ["numeric", "2-digit"][len - 1];
          break;
        case "s":
          result.second = ["numeric", "2-digit"][len - 1];
          break;
        case "S":
        case "A":
          throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
        case "z":
          result.timeZoneName = len < 4 ? "short" : "long";
          break;
        case "Z":
        case "O":
        case "v":
        case "V":
        case "X":
        case "x":
          throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
      }
      return "";
    }), result;
  }
  var WHITE_SPACE_REGEX = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
  function parseNumberSkeletonFromString(skeleton) {
    if (skeleton.length === 0) throw new Error("Number skeleton cannot be empty");
    let stringTokens = skeleton.split(WHITE_SPACE_REGEX).filter((x) => x.length > 0), tokens = [];
    for (let stringToken of stringTokens) {
      let stemAndOptions = stringToken.split("/");
      if (stemAndOptions.length === 0) throw new Error("Invalid number skeleton");
      let [stem, ...options] = stemAndOptions;
      for (let option of options) if (option.length === 0) throw new Error("Invalid number skeleton");
      tokens.push({
        stem,
        options
      });
    }
    return tokens;
  }
  function icuUnitToEcma(unit) {
    return unit.replace(/^(.*?)-/, "");
  }
  var FRACTION_PRECISION_REGEX = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, SIGNIFICANT_PRECISION_REGEX = /^(@+)?(\+|#+)?[rs]?$/g, INTEGER_WIDTH_REGEX = /(\*)(0+)|(#+)(0+)|(0+)/g, CONCISE_INTEGER_WIDTH_REGEX = /^(0+)$/;
  function parseSignificantPrecision(str) {
    let result = {};
    return str[str.length - 1] === "r" ? result.roundingPriority = "morePrecision" : str[str.length - 1] === "s" && (result.roundingPriority = "lessPrecision"), str.replace(SIGNIFICANT_PRECISION_REGEX, function(_, g1, g2) {
      return typeof g2 != "string" ? (result.minimumSignificantDigits = g1.length, result.maximumSignificantDigits = g1.length) : g2 === "+" ? result.minimumSignificantDigits = g1.length : g1[0] === "#" ? result.maximumSignificantDigits = g1.length : (result.minimumSignificantDigits = g1.length, result.maximumSignificantDigits = g1.length + (typeof g2 == "string" ? g2.length : 0)), "";
    }), result;
  }
  function parseSign(str) {
    switch (str) {
      case "sign-auto":
        return { signDisplay: "auto" };
      case "sign-accounting":
      case "()":
        return { currencySign: "accounting" };
      case "sign-always":
      case "+!":
        return { signDisplay: "always" };
      case "sign-accounting-always":
      case "()!":
        return {
          signDisplay: "always",
          currencySign: "accounting"
        };
      case "sign-except-zero":
      case "+?":
        return { signDisplay: "exceptZero" };
      case "sign-accounting-except-zero":
      case "()?":
        return {
          signDisplay: "exceptZero",
          currencySign: "accounting"
        };
      case "sign-never":
      case "+_":
        return { signDisplay: "never" };
    }
  }
  function parseConciseScientificAndEngineeringStem(stem) {
    let result;
    if (stem[0] === "E" && stem[1] === "E" ? (result = { notation: "engineering" }, stem = stem.slice(2)) : stem[0] === "E" && (result = { notation: "scientific" }, stem = stem.slice(1)), result) {
      let signDisplay = stem.slice(0, 2);
      if (signDisplay === "+!" ? (result.signDisplay = "always", stem = stem.slice(2)) : signDisplay === "+?" && (result.signDisplay = "exceptZero", stem = stem.slice(2)), !CONCISE_INTEGER_WIDTH_REGEX.test(stem)) throw new Error("Malformed concise eng/scientific notation");
      result.minimumIntegerDigits = stem.length;
    }
    return result;
  }
  function parseNotationOptions(opt) {
    let result = {}, signOpts = parseSign(opt);
    return signOpts || result;
  }
  function parseNumberSkeleton(tokens) {
    let result = {};
    for (let token of tokens) {
      switch (token.stem) {
        case "percent":
        case "%":
          result.style = "percent";
          continue;
        case "%x100":
          result.style = "percent", result.scale = 100;
          continue;
        case "currency":
          result.style = "currency", result.currency = token.options[0];
          continue;
        case "group-off":
        case ",_":
          result.useGrouping = !1;
          continue;
        case "precision-integer":
        case ".":
          result.maximumFractionDigits = 0;
          continue;
        case "measure-unit":
        case "unit":
          result.style = "unit", result.unit = icuUnitToEcma(token.options[0]);
          continue;
        case "compact-short":
        case "K":
          result.notation = "compact", result.compactDisplay = "short";
          continue;
        case "compact-long":
        case "KK":
          result.notation = "compact", result.compactDisplay = "long";
          continue;
        case "scientific":
          result = __spreadValues(__spreadProps(__spreadValues({}, result), {
            notation: "scientific"
          }), token.options.reduce((all, opt) => __spreadValues(__spreadValues({}, all), parseNotationOptions(opt)), {}));
          continue;
        case "engineering":
          result = __spreadValues(__spreadProps(__spreadValues({}, result), {
            notation: "engineering"
          }), token.options.reduce((all, opt) => __spreadValues(__spreadValues({}, all), parseNotationOptions(opt)), {}));
          continue;
        case "notation-simple":
          result.notation = "standard";
          continue;
        case "unit-width-narrow":
          result.currencyDisplay = "narrowSymbol", result.unitDisplay = "narrow";
          continue;
        case "unit-width-short":
          result.currencyDisplay = "code", result.unitDisplay = "short";
          continue;
        case "unit-width-full-name":
          result.currencyDisplay = "name", result.unitDisplay = "long";
          continue;
        case "unit-width-iso-code":
          result.currencyDisplay = "symbol";
          continue;
        case "scale":
          result.scale = parseFloat(token.options[0]);
          continue;
        case "rounding-mode-floor":
          result.roundingMode = "floor";
          continue;
        case "rounding-mode-ceiling":
          result.roundingMode = "ceil";
          continue;
        case "rounding-mode-down":
          result.roundingMode = "trunc";
          continue;
        case "rounding-mode-up":
          result.roundingMode = "expand";
          continue;
        case "rounding-mode-half-even":
          result.roundingMode = "halfEven";
          continue;
        case "rounding-mode-half-down":
          result.roundingMode = "halfTrunc";
          continue;
        case "rounding-mode-half-up":
          result.roundingMode = "halfExpand";
          continue;
        case "integer-width":
          if (token.options.length > 1) throw new RangeError("integer-width stems only accept a single optional option");
          token.options[0].replace(INTEGER_WIDTH_REGEX, function(_, g1, g2, g3, g4, g5) {
            if (g1) result.minimumIntegerDigits = g2.length;
            else {
              if (g3 && g4) throw new Error("We currently do not support maximum integer digits");
              if (g5) throw new Error("We currently do not support exact integer digits");
            }
            return "";
          });
          continue;
      }
      if (CONCISE_INTEGER_WIDTH_REGEX.test(token.stem)) {
        result.minimumIntegerDigits = token.stem.length;
        continue;
      }
      if (FRACTION_PRECISION_REGEX.test(token.stem)) {
        if (token.options.length > 1) throw new RangeError("Fraction-precision stems only accept a single optional option");
        token.stem.replace(FRACTION_PRECISION_REGEX, function(_, g1, g2, g3, g4, g5) {
          return g2 === "*" ? result.minimumFractionDigits = g1.length : g3 && g3[0] === "#" ? result.maximumFractionDigits = g3.length : g4 && g5 ? (result.minimumFractionDigits = g4.length, result.maximumFractionDigits = g4.length + g5.length) : (result.minimumFractionDigits = g1.length, result.maximumFractionDigits = g1.length), "";
        });
        let opt = token.options[0];
        opt === "w" ? result = __spreadProps(__spreadValues({}, result), {
          trailingZeroDisplay: "stripIfInteger"
        }) : opt && (result = __spreadValues(__spreadValues({}, result), parseSignificantPrecision(opt)));
        continue;
      }
      if (SIGNIFICANT_PRECISION_REGEX.test(token.stem)) {
        result = __spreadValues(__spreadValues({}, result), parseSignificantPrecision(token.stem));
        continue;
      }
      let signOpts = parseSign(token.stem);
      signOpts && (result = __spreadValues(__spreadValues({}, result), signOpts));
      let conciseScientificAndEngineeringOpts = parseConciseScientificAndEngineeringStem(token.stem);
      conciseScientificAndEngineeringOpts && (result = __spreadValues(__spreadValues({}, result), conciseScientificAndEngineeringOpts));
    }
    return result;
  }

  // node_modules/@formatjs/icu-messageformat-parser/index.js
  var ErrorKind = /* @__PURE__ */ (function(ErrorKind2) {
    return ErrorKind2[ErrorKind2.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", ErrorKind2[ErrorKind2.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", ErrorKind2[ErrorKind2.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", ErrorKind2[ErrorKind2.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", ErrorKind2[ErrorKind2.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", ErrorKind2[ErrorKind2.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", ErrorKind2[ErrorKind2.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", ErrorKind2[ErrorKind2.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", ErrorKind2[ErrorKind2.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", ErrorKind2[ErrorKind2.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", ErrorKind2[ErrorKind2.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", ErrorKind2[ErrorKind2.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", ErrorKind2[ErrorKind2.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", ErrorKind2[ErrorKind2.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", ErrorKind2[ErrorKind2.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", ErrorKind2[ErrorKind2.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", ErrorKind2[ErrorKind2.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", ErrorKind2[ErrorKind2.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", ErrorKind2[ErrorKind2.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", ErrorKind2[ErrorKind2.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", ErrorKind2[ErrorKind2.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", ErrorKind2[ErrorKind2.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", ErrorKind2[ErrorKind2.INVALID_TAG = 23] = "INVALID_TAG", ErrorKind2[ErrorKind2.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", ErrorKind2[ErrorKind2.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", ErrorKind2[ErrorKind2.UNCLOSED_TAG = 27] = "UNCLOSED_TAG", ErrorKind2;
  })({}), TYPE = /* @__PURE__ */ (function(TYPE2) {
    return TYPE2[TYPE2.literal = 0] = "literal", TYPE2[TYPE2.argument = 1] = "argument", TYPE2[TYPE2.number = 2] = "number", TYPE2[TYPE2.date = 3] = "date", TYPE2[TYPE2.time = 4] = "time", TYPE2[TYPE2.select = 5] = "select", TYPE2[TYPE2.plural = 6] = "plural", TYPE2[TYPE2.pound = 7] = "pound", TYPE2[TYPE2.tag = 8] = "tag", TYPE2;
  })({});
  function isNumberElement(el) {
    return el.type === 2;
  }
  function isDateElement(el) {
    return el.type === 3;
  }
  function isTimeElement(el) {
    return el.type === 4;
  }
  function isSelectElement(el) {
    return el.type === 5;
  }
  function isPluralElement(el) {
    return el.type === 6;
  }
  function isTagElement(el) {
    return el.type === 8;
  }
  function isNumberSkeleton(el) {
    return !!(el && typeof el == "object" && el.type === 0);
  }
  function isDateTimeSkeleton(el) {
    return !!(el && typeof el == "object" && el.type === 1);
  }
  var SPACE_SEPARATOR_REGEX = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, IDENTIFIER_PREFIX_REGEX = /([^\t-\r -\/:-@\[-\^`\{-~\x85\xA0-\xA7\xA9\xAB\xAC\xAE\xB0\xB1\xB6\xBB\xBF\xD7\xF7\u1680\u2000-\u200A\u2010-\u2029\u202F-\u203E\u2041-\u2053\u2055-\u205F\u2190-\u245F\u2500-\u2775\u2794-\u2BFF\u2E00-\u2E7F\u3000-\u3003\u3008-\u3020\u3030\uFD3E\uFD3F\uFE45\uFE46]*)/g, timeData = {
    "001": ["H", "h"],
    419: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    AC: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    AD: ["H", "hB"],
    AE: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    AF: [
      "H",
      "hb",
      "hB",
      "h"
    ],
    AG: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    AI: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    AL: [
      "h",
      "H",
      "hB"
    ],
    AM: ["H", "hB"],
    AO: ["H", "hB"],
    AR: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    AS: ["h", "H"],
    AT: ["H", "hB"],
    AU: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    AW: ["H", "hB"],
    AX: ["H"],
    AZ: [
      "H",
      "hB",
      "h"
    ],
    BA: [
      "H",
      "hB",
      "h"
    ],
    BB: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    BD: [
      "h",
      "hB",
      "H"
    ],
    BE: ["H", "hB"],
    BF: ["H", "hB"],
    BG: [
      "H",
      "hB",
      "h"
    ],
    BH: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    BI: ["H", "h"],
    BJ: ["H", "hB"],
    BL: ["H", "hB"],
    BM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    BN: [
      "hb",
      "hB",
      "h",
      "H"
    ],
    BO: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    BQ: ["H"],
    BR: ["H", "hB"],
    BS: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    BT: ["h", "H"],
    BW: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    BY: ["H", "h"],
    BZ: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    CA: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    CC: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    CD: ["hB", "H"],
    CF: [
      "H",
      "h",
      "hB"
    ],
    CG: ["H", "hB"],
    CH: [
      "H",
      "hB",
      "h"
    ],
    CI: ["H", "hB"],
    CK: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    CL: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    CM: [
      "H",
      "h",
      "hB"
    ],
    CN: [
      "H",
      "hB",
      "hb",
      "h"
    ],
    CO: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    CP: ["H"],
    CR: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    CU: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    CV: ["H", "hB"],
    CW: ["H", "hB"],
    CX: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    CY: [
      "h",
      "H",
      "hb",
      "hB"
    ],
    CZ: ["H"],
    DE: ["H", "hB"],
    DG: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    DJ: ["h", "H"],
    DK: ["H"],
    DM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    DO: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    DZ: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    EA: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    EC: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    EE: ["H", "hB"],
    EG: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    EH: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    ER: ["h", "H"],
    ES: [
      "H",
      "hB",
      "h",
      "hb"
    ],
    ET: [
      "hB",
      "hb",
      "h",
      "H"
    ],
    FI: ["H"],
    FJ: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    FK: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    FM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    FO: ["H", "h"],
    FR: ["H", "hB"],
    GA: ["H", "hB"],
    GB: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    GD: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    GE: [
      "H",
      "hB",
      "h"
    ],
    GF: ["H", "hB"],
    GG: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    GH: ["h", "H"],
    GI: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    GL: ["H", "h"],
    GM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    GN: ["H", "hB"],
    GP: ["H", "hB"],
    GQ: [
      "H",
      "hB",
      "h",
      "hb"
    ],
    GR: [
      "h",
      "H",
      "hb",
      "hB"
    ],
    GS: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    GT: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    GU: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    GW: ["H", "hB"],
    GY: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    HK: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    HN: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    HR: ["H", "hB"],
    HU: ["H", "h"],
    IC: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    ID: ["H"],
    IE: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    IL: ["H", "hB"],
    IM: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    IN: ["h", "H"],
    IO: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    IQ: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    IR: ["hB", "H"],
    IS: ["H"],
    IT: ["H", "hB"],
    JE: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    JM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    JO: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    JP: [
      "H",
      "K",
      "h"
    ],
    KE: [
      "hB",
      "hb",
      "H",
      "h"
    ],
    KG: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    KH: [
      "hB",
      "h",
      "H",
      "hb"
    ],
    KI: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    KM: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    KN: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    KP: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    KR: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    KW: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    KY: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    KZ: ["H", "hB"],
    LA: [
      "H",
      "hb",
      "hB",
      "h"
    ],
    LB: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    LC: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    LI: [
      "H",
      "hB",
      "h"
    ],
    LK: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    LR: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    LS: ["h", "H"],
    LT: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    LU: [
      "H",
      "h",
      "hB"
    ],
    LV: [
      "H",
      "hB",
      "hb",
      "h"
    ],
    LY: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    MA: [
      "H",
      "h",
      "hB",
      "hb"
    ],
    MC: ["H", "hB"],
    MD: ["H", "hB"],
    ME: [
      "H",
      "hB",
      "h"
    ],
    MF: ["H", "hB"],
    MG: ["H", "h"],
    MH: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    MK: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    ML: ["H"],
    MM: [
      "hB",
      "hb",
      "H",
      "h"
    ],
    MN: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    MO: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    MP: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    MQ: ["H", "hB"],
    MR: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    MS: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    MT: ["H", "h"],
    MU: ["H", "h"],
    MV: ["H", "h"],
    MW: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    MX: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    MY: [
      "hb",
      "hB",
      "h",
      "H"
    ],
    MZ: ["H", "hB"],
    NA: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    NC: ["H", "hB"],
    NE: ["H"],
    NF: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    NG: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    NI: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    NL: ["H", "hB"],
    NO: ["H", "h"],
    NP: [
      "H",
      "h",
      "hB"
    ],
    NR: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    NU: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    NZ: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    OM: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    PA: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    PE: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    PF: [
      "H",
      "h",
      "hB"
    ],
    PG: ["h", "H"],
    PH: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    PK: [
      "h",
      "hB",
      "H"
    ],
    PL: ["H", "h"],
    PM: ["H", "hB"],
    PN: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    PR: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    PS: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    PT: ["H", "hB"],
    PW: ["h", "H"],
    PY: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    QA: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    RE: ["H", "hB"],
    RO: ["H", "hB"],
    RS: [
      "H",
      "hB",
      "h"
    ],
    RU: ["H"],
    RW: ["H", "h"],
    SA: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    SB: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    SC: [
      "H",
      "h",
      "hB"
    ],
    SD: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    SE: ["H"],
    SG: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    SH: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    SI: ["H", "hB"],
    SJ: ["H"],
    SK: ["H"],
    SL: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    SM: [
      "H",
      "h",
      "hB"
    ],
    SN: [
      "H",
      "h",
      "hB"
    ],
    SO: ["h", "H"],
    SR: ["H", "hB"],
    SS: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    ST: ["H", "hB"],
    SV: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    SX: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    SY: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    SZ: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    TA: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    TC: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    TD: [
      "h",
      "H",
      "hB"
    ],
    TF: [
      "H",
      "h",
      "hB"
    ],
    TG: ["H", "hB"],
    TH: ["H", "h"],
    TJ: ["H", "h"],
    TL: [
      "H",
      "hB",
      "hb",
      "h"
    ],
    TM: ["H", "h"],
    TN: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    TO: ["h", "H"],
    TR: ["H", "hB"],
    TT: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    TW: [
      "hB",
      "hb",
      "h",
      "H"
    ],
    TZ: [
      "hB",
      "hb",
      "H",
      "h"
    ],
    UA: [
      "H",
      "hB",
      "h"
    ],
    UG: [
      "hB",
      "hb",
      "H",
      "h"
    ],
    UM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    US: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    UY: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    UZ: [
      "H",
      "hB",
      "h"
    ],
    VA: [
      "H",
      "h",
      "hB"
    ],
    VC: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    VE: [
      "h",
      "H",
      "hB",
      "hb"
    ],
    VG: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    VI: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    VN: ["H", "h"],
    VU: ["h", "H"],
    WF: ["H", "hB"],
    WS: ["h", "H"],
    XK: [
      "H",
      "hB",
      "h"
    ],
    YE: [
      "h",
      "hB",
      "hb",
      "H"
    ],
    YT: ["H", "hB"],
    ZA: [
      "H",
      "h",
      "hb",
      "hB"
    ],
    ZM: [
      "h",
      "hb",
      "H",
      "hB"
    ],
    ZW: ["H", "h"],
    "af-ZA": [
      "H",
      "h",
      "hB",
      "hb"
    ],
    "ar-001": [
      "h",
      "hB",
      "hb",
      "H"
    ],
    "ca-ES": [
      "H",
      "h",
      "hB"
    ],
    "en-001": [
      "h",
      "hb",
      "H",
      "hB"
    ],
    "en-HK": [
      "h",
      "hb",
      "H",
      "hB"
    ],
    "en-IL": [
      "H",
      "h",
      "hb",
      "hB"
    ],
    "en-MY": [
      "h",
      "hb",
      "H",
      "hB"
    ],
    "es-BR": [
      "H",
      "h",
      "hB",
      "hb"
    ],
    "es-ES": [
      "H",
      "h",
      "hB",
      "hb"
    ],
    "es-GQ": [
      "H",
      "h",
      "hB",
      "hb"
    ],
    "fr-CA": [
      "H",
      "h",
      "hB"
    ],
    "gl-ES": [
      "H",
      "h",
      "hB"
    ],
    "gu-IN": [
      "hB",
      "hb",
      "h",
      "H"
    ],
    "hi-IN": [
      "hB",
      "h",
      "H"
    ],
    "it-CH": [
      "H",
      "h",
      "hB"
    ],
    "it-IT": [
      "H",
      "h",
      "hB"
    ],
    "kn-IN": [
      "hB",
      "h",
      "H"
    ],
    "ku-SY": ["H", "hB"],
    "ml-IN": [
      "hB",
      "h",
      "H"
    ],
    "mr-IN": [
      "hB",
      "hb",
      "h",
      "H"
    ],
    "pa-IN": [
      "hB",
      "hb",
      "h",
      "H"
    ],
    "ta-IN": [
      "hB",
      "h",
      "hb",
      "H"
    ],
    "te-IN": [
      "hB",
      "h",
      "H"
    ],
    "zu-ZA": [
      "H",
      "hB",
      "hb",
      "h"
    ]
  };
  function getBestPattern(skeleton, locale) {
    let skeletonCopy = "";
    for (let patternPos = 0; patternPos < skeleton.length; patternPos++) {
      let patternChar = skeleton.charAt(patternPos);
      if (patternChar === "j") {
        let extraLength = 0;
        for (; patternPos + 1 < skeleton.length && skeleton.charAt(patternPos + 1) === patternChar; )
          extraLength++, patternPos++;
        let hourLen = 1 + (extraLength & 1), dayPeriodLen = extraLength < 2 ? 1 : 3 + (extraLength >> 1), dayPeriodChar = "a", hourChar = getDefaultHourSymbolFromLocale(locale);
        for ((hourChar == "H" || hourChar == "k") && (dayPeriodLen = 0); dayPeriodLen-- > 0; ) skeletonCopy += dayPeriodChar;
        for (; hourLen-- > 0; ) skeletonCopy = hourChar + skeletonCopy;
      } else patternChar === "J" ? skeletonCopy += "H" : skeletonCopy += patternChar;
    }
    return skeletonCopy;
  }
  function getDefaultHourSymbolFromLocale(locale) {
    var _a, _b, _c;
    let hourCycle = locale.hourCycle;
    if (hourCycle === void 0) {
      let localeWithHourCycles = locale;
      hourCycle = (_c = (_a = localeWithHourCycles.getHourCycles) == null ? void 0 : _a.call(localeWithHourCycles)[0]) != null ? _c : (_b = localeWithHourCycles.hourCycles) == null ? void 0 : _b[0];
    }
    if (hourCycle) switch (hourCycle) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
    let languageTag = locale.language, regionTag;
    return languageTag !== "root" && (regionTag = locale.maximize().region), (timeData[`${languageTag}-${regionTag}`] || timeData[regionTag || ""] || timeData[languageTag || ""] || timeData[`${languageTag}-001`] || timeData["001"])[0].charAt(0);
  }
  var SPACE_SEPARATOR_START_REGEX = new RegExp(`^${SPACE_SEPARATOR_REGEX.source}*`), SPACE_SEPARATOR_END_REGEX = new RegExp(`${SPACE_SEPARATOR_REGEX.source}*$`);
  function createLocation(start, end) {
    return {
      start,
      end
    };
  }
  var hasNativeFromEntries = !!Object.fromEntries, hasTrimStart = !!String.prototype.trimStart, hasTrimEnd = !!String.prototype.trimEnd, fromEntries = hasNativeFromEntries ? Object.fromEntries : function(entries) {
    let obj = {};
    for (let [k, v] of entries) obj[k] = v;
    return obj;
  }, trimStart = hasTrimStart ? function(s) {
    return s.trimStart();
  } : function(s) {
    return s.replace(SPACE_SEPARATOR_START_REGEX, "");
  }, trimEnd = hasTrimEnd ? function(s) {
    return s.trimEnd();
  } : function(s) {
    return s.replace(SPACE_SEPARATOR_END_REGEX, "");
  }, IDENTIFIER_PREFIX_RE = createIdentifierPrefixRegex();
  function createIdentifierPrefixRegex() {
    var _a;
    try {
      let regex = new RegExp("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
      if (((_a = regex.exec("a ")) == null ? void 0 : _a[1]) === "a") return regex;
    } catch (e) {
    }
    return IDENTIFIER_PREFIX_REGEX;
  }
  function matchIdentifierAtIndex(s, index) {
    var _a;
    return IDENTIFIER_PREFIX_RE.lastIndex = index, (_a = IDENTIFIER_PREFIX_RE.exec(s)[1]) != null ? _a : "";
  }
  function plainTopLevelEndPosition(message) {
    if (message.length === 0) return null;
    let line = 1, column = 1;
    for (let offset = 0; offset < message.length; ) {
      let code = message.charCodeAt(offset);
      switch (code) {
        case 35:
        case 39:
        case 60:
        case 123:
        case 125:
          return null;
      }
      if (code === 10)
        line++, column = 1, offset++;
      else if (column++, code >= 55296 && code <= 56319 && offset + 1 < message.length) {
        let next = message.charCodeAt(offset + 1);
        offset += next >= 56320 && next <= 57343 ? 2 : 1;
      } else offset++;
    }
    return {
      offset: message.length,
      line,
      column
    };
  }
  var Parser = class {
    constructor(message, options = {}) {
      this.message = message, this.position = {
        offset: 0,
        line: 1,
        column: 1
      }, this.ignoreTag = !!options.ignoreTag, this.locale = options.locale, this.requiresOtherClause = !!options.requiresOtherClause, this.shouldParseSkeletons = !!options.shouldParseSkeletons;
    }
    parse() {
      if (this.offset() !== 0) throw Error("parser can only be used once");
      if (this.message.length > 0) {
        let firstCode = this.message.charCodeAt(0);
        if (firstCode !== 35 && firstCode !== 39 && firstCode !== 60 && firstCode !== 123 && firstCode !== 125) {
          let plainEndPosition = plainTopLevelEndPosition(this.message);
          if (plainEndPosition) {
            let start = this.clonePosition();
            return this.position = plainEndPosition, {
              val: [{
                type: 0,
                value: this.message,
                location: createLocation(start, this.clonePosition())
              }],
              err: null
            };
          }
        }
      }
      return this.parseMessage(0, "", !1);
    }
    parseMessage(nestingLevel, parentArgType, expectingCloseTag) {
      let elements = [];
      for (; !this.isEOF(); ) {
        let char = this.char();
        if (char === 123) {
          let result = this.parseArgument(nestingLevel, expectingCloseTag);
          if (result.err) return result;
          elements.push(result.val);
        } else {
          if (char === 125 && nestingLevel > 0) break;
          if (char === 35 && (parentArgType === "plural" || parentArgType === "selectordinal")) {
            let position = this.clonePosition();
            this.bump(), elements.push({
              type: 7,
              location: createLocation(position, this.clonePosition())
            });
          } else if (char === 60 && !this.ignoreTag && this.peek() === 47) {
            if (expectingCloseTag) break;
            return this.error(26, createLocation(this.clonePosition(), this.clonePosition()));
          } else if (char === 60 && !this.ignoreTag && _isAlpha(this.peek() || 0)) {
            let result = this.parseTag(nestingLevel, parentArgType);
            if (result.err) return result;
            elements.push(result.val);
          } else {
            let result = this.parseLiteral(nestingLevel, parentArgType);
            if (result.err) return result;
            elements.push(result.val);
          }
        }
      }
      return {
        val: elements,
        err: null
      };
    }
    /**
    * A tag name must start with an ASCII lower/upper case letter. The grammar is based on the
    * [custom element name][] except that a dash is NOT always mandatory and uppercase letters
    * are accepted:
    *
    * ```
    * tag ::= "<" tagName (whitespace)* "/>" | "<" tagName (whitespace)* ">" message "</" tagName (whitespace)* ">"
    * tagName ::= [a-z] (PENChar)*
    * PENChar ::=
    *     "-" | "." | [0-9] | "_" | [a-z] | [A-Z] | #xB7 | [#xC0-#xD6] | [#xD8-#xF6] | [#xF8-#x37D] |
    *     [#x37F-#x1FFF] | [#x200C-#x200D] | [#x203F-#x2040] | [#x2070-#x218F] | [#x2C00-#x2FEF] |
    *     [#x3001-#xD7FF] | [#xF900-#xFDCF] | [#xFDF0-#xFFFD] | [#x10000-#xEFFFF]
    * ```
    *
    * [custom element name]: https://html.spec.whatwg.org/multipage/custom-elements.html#valid-custom-element-name
    * NOTE: We're a bit more lax here since HTML technically does not allow uppercase HTML element but we do
    * since other tag-based engines like React allow it
    */
    parseTag(nestingLevel, parentArgType) {
      let startPosition = this.clonePosition();
      this.bump();
      let tagName = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>")) return {
        val: {
          type: 0,
          value: `<${tagName}/>`,
          location: createLocation(startPosition, this.clonePosition())
        },
        err: null
      };
      if (this.bumpIf(">")) {
        let childrenResult = this.parseMessage(nestingLevel + 1, parentArgType, !0);
        if (childrenResult.err) return childrenResult;
        let children = childrenResult.val, endTagStartPosition = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !_isAlpha(this.char())) return this.error(23, createLocation(endTagStartPosition, this.clonePosition()));
          let closingTagNameStartPosition = this.clonePosition();
          return tagName !== this.parseTagName() ? this.error(26, createLocation(closingTagNameStartPosition, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: 8,
              value: tagName,
              children,
              location: createLocation(startPosition, this.clonePosition())
            },
            err: null
          } : this.error(23, createLocation(endTagStartPosition, this.clonePosition())));
        } else return this.error(27, createLocation(startPosition, this.clonePosition()));
      } else return this.error(23, createLocation(startPosition, this.clonePosition()));
    }
    /**
    * This method assumes that the caller has peeked ahead for the first tag character.
    */
    parseTagName() {
      let startOffset = this.offset();
      for (this.bump(); !this.isEOF() && _isPotentialElementNameChar(this.char()); ) this.bump();
      return this.message.slice(startOffset, this.offset());
    }
    parseLiteral(nestingLevel, parentArgType) {
      let start = this.clonePosition(), value = "";
      for (; ; ) {
        let parseQuoteResult = this.tryParseQuote(parentArgType);
        if (parseQuoteResult) {
          value += parseQuoteResult;
          continue;
        }
        let parseUnquotedResult = this.tryParseUnquoted(nestingLevel, parentArgType);
        if (parseUnquotedResult) {
          value += parseUnquotedResult;
          continue;
        }
        let parseLeftAngleResult = this.tryParseLeftAngleBracket();
        if (parseLeftAngleResult) {
          value += parseLeftAngleResult;
          continue;
        }
        break;
      }
      let location = createLocation(start, this.clonePosition());
      return {
        val: {
          type: 0,
          value,
          location
        },
        err: null
      };
    }
    tryParseLeftAngleBracket() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || !_isAlphaOrSlash(this.peek() || 0)) ? (this.bump(), "<") : null;
    }
    /**
    * Starting with ICU 4.8, an ASCII apostrophe only starts quoted text if it immediately precedes
    * a character that requires quoting (that is, "only where needed"), and works the same in
    * nested messages as on the top level of the pattern. The new behavior is otherwise compatible.
    */
    tryParseQuote(parentArgType) {
      if (this.isEOF() || this.char() !== 39) return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (parentArgType === "plural" || parentArgType === "selectordinal") break;
          return null;
        default:
          return null;
      }
      this.bump();
      let codePoints = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        let ch = this.char();
        if (ch === 39)
          if (this.peek() === 39)
            codePoints.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else codePoints.push(ch);
        this.bump();
      }
      return String.fromCodePoint(...codePoints);
    }
    tryParseUnquoted(nestingLevel, parentArgType) {
      if (this.isEOF()) return null;
      let ch = this.char();
      return ch === 60 || ch === 123 || ch === 35 && (parentArgType === "plural" || parentArgType === "selectordinal") || ch === 125 && nestingLevel > 0 ? null : (this.bump(), String.fromCodePoint(ch));
    }
    parseArgument(nestingLevel, expectingCloseTag) {
      let openingBracePosition = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF()) return this.error(1, createLocation(openingBracePosition, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(2, createLocation(openingBracePosition, this.clonePosition()));
      let value = this.parseIdentifierIfPossible().value;
      if (!value) return this.error(3, createLocation(openingBracePosition, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF()) return this.error(1, createLocation(openingBracePosition, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: 1,
              value,
              location: createLocation(openingBracePosition, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(1, createLocation(openingBracePosition, this.clonePosition())) : this.parseArgumentOptions(nestingLevel, expectingCloseTag, value, openingBracePosition);
        default:
          return this.error(3, createLocation(openingBracePosition, this.clonePosition()));
      }
    }
    /**
    * Advance the parser until the end of the identifier, if it is currently on
    * an identifier character. Return an empty string otherwise.
    */
    parseIdentifierIfPossible() {
      let startingPosition = this.clonePosition(), startOffset = this.offset(), value = matchIdentifierAtIndex(this.message, startOffset), endOffset = startOffset + value.length;
      return this.bumpTo(endOffset), {
        value,
        location: createLocation(startingPosition, this.clonePosition())
      };
    }
    parseArgumentOptions(nestingLevel, expectingCloseTag, value, openingBracePosition) {
      var _a;
      let typeStartPosition = this.clonePosition(), argType = this.parseIdentifierIfPossible().value, typeEndPosition = this.clonePosition();
      switch (argType) {
        case "":
          return this.error(4, createLocation(typeStartPosition, typeEndPosition));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          let styleAndLocation = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            let styleStartPosition = this.clonePosition(), result = this.parseSimpleArgStyleIfPossible();
            if (result.err) return result;
            let style = trimEnd(result.val);
            if (style.length === 0) return this.error(6, createLocation(this.clonePosition(), this.clonePosition()));
            styleAndLocation = {
              style,
              styleLocation: createLocation(styleStartPosition, this.clonePosition())
            };
          }
          let argCloseResult = this.tryParseArgumentClose(openingBracePosition);
          if (argCloseResult.err) return argCloseResult;
          let location = createLocation(openingBracePosition, this.clonePosition());
          if (styleAndLocation && styleAndLocation.style.startsWith("::")) {
            let skeleton = trimStart(styleAndLocation.style.slice(2));
            if (argType === "number") {
              let result = this.parseNumberSkeletonFromString(skeleton, styleAndLocation.styleLocation);
              return result.err ? result : {
                val: {
                  type: 2,
                  value,
                  location,
                  style: result.val
                },
                err: null
              };
            } else {
              if (skeleton.length === 0) return this.error(10, location);
              let dateTimePattern = skeleton;
              this.locale && (dateTimePattern = getBestPattern(skeleton, this.locale));
              let style = {
                type: 1,
                pattern: dateTimePattern,
                location: styleAndLocation.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? parseDateTimeSkeleton(dateTimePattern) : {}
              };
              return {
                val: {
                  type: argType === "date" ? 3 : 4,
                  value,
                  location,
                  style
                },
                err: null
              };
            }
          }
          return {
            val: {
              type: argType === "number" ? 2 : argType === "date" ? 3 : 4,
              value,
              location,
              style: (_a = styleAndLocation == null ? void 0 : styleAndLocation.style) != null ? _a : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          let typeEndPosition2 = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(",")) return this.error(12, createLocation(typeEndPosition2, __spreadValues({}, typeEndPosition2)));
          this.bumpSpace();
          let identifierAndLocation = this.parseIdentifierIfPossible(), pluralOffset = 0;
          if (argType !== "select" && identifierAndLocation.value === "offset") {
            if (!this.bumpIf(":")) return this.error(13, createLocation(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            let result = this.tryParseDecimalInteger(13, 14);
            if (result.err) return result;
            this.bumpSpace(), identifierAndLocation = this.parseIdentifierIfPossible(), pluralOffset = result.val;
          }
          let optionsResult = this.tryParsePluralOrSelectOptions(nestingLevel, argType, expectingCloseTag, identifierAndLocation);
          if (optionsResult.err) return optionsResult;
          let argCloseResult = this.tryParseArgumentClose(openingBracePosition);
          if (argCloseResult.err) return argCloseResult;
          let location = createLocation(openingBracePosition, this.clonePosition());
          return argType === "select" ? {
            val: {
              type: 5,
              value,
              options: fromEntries(optionsResult.val),
              location
            },
            err: null
          } : {
            val: {
              type: 6,
              value,
              options: fromEntries(optionsResult.val),
              offset: pluralOffset,
              pluralType: argType === "plural" ? "cardinal" : "ordinal",
              location
            },
            err: null
          };
        }
        default:
          return this.error(5, createLocation(typeStartPosition, typeEndPosition));
      }
    }
    tryParseArgumentClose(openingBracePosition) {
      return this.isEOF() || this.char() !== 125 ? this.error(1, createLocation(openingBracePosition, this.clonePosition())) : (this.bump(), {
        val: !0,
        err: null
      });
    }
    /**
    * See: https://github.com/unicode-org/icu/blob/af7ed1f6d2298013dc303628438ec4abe1f16479/icu4c/source/common/messagepattern.cpp#L659
    */
    parseSimpleArgStyleIfPossible() {
      let nestedBraces = 0, startPosition = this.clonePosition();
      for (; !this.isEOF(); ) switch (this.char()) {
        case 39: {
          this.bump();
          let apostrophePosition = this.clonePosition();
          if (!this.bumpUntil("'")) return this.error(11, createLocation(apostrophePosition, this.clonePosition()));
          this.bump();
          break;
        }
        case 123:
          nestedBraces += 1, this.bump();
          break;
        case 125:
          if (nestedBraces > 0) nestedBraces -= 1;
          else return {
            val: this.message.slice(startPosition.offset, this.offset()),
            err: null
          };
          break;
        default:
          this.bump();
      }
      return {
        val: this.message.slice(startPosition.offset, this.offset()),
        err: null
      };
    }
    parseNumberSkeletonFromString(skeleton, location) {
      let tokens = [];
      try {
        tokens = parseNumberSkeletonFromString(skeleton);
      } catch (e) {
        return this.error(7, location);
      }
      return {
        val: {
          type: 0,
          tokens,
          location,
          parsedOptions: this.shouldParseSkeletons ? parseNumberSkeleton(tokens) : {}
        },
        err: null
      };
    }
    /**
    * @param nesting_level The current nesting level of messages.
    *     This can be positive when parsing message fragment in select or plural argument options.
    * @param parent_arg_type The parent argument's type.
    * @param parsed_first_identifier If provided, this is the first identifier-like selector of
    *     the argument. It is a by-product of a previous parsing attempt.
    * @param expecting_close_tag If true, this message is directly or indirectly nested inside
    *     between a pair of opening and closing tags. The nested message will not parse beyond
    *     the closing tag boundary.
    */
    tryParsePluralOrSelectOptions(nestingLevel, parentArgType, expectCloseTag, parsedFirstIdentifier) {
      let hasOtherClause = !1, options = [], parsedSelectors = /* @__PURE__ */ new Set(), { value: selector, location: selectorLocation } = parsedFirstIdentifier;
      for (; ; ) {
        if (selector.length === 0) {
          let startPosition = this.clonePosition();
          if (parentArgType !== "select" && this.bumpIf("=")) {
            let result = this.tryParseDecimalInteger(16, 19);
            if (result.err) return result;
            selectorLocation = createLocation(startPosition, this.clonePosition()), selector = this.message.slice(startPosition.offset, this.offset());
          } else break;
        }
        if (parsedSelectors.has(selector)) return this.error(parentArgType === "select" ? 21 : 20, selectorLocation);
        selector === "other" && (hasOtherClause = !0), this.bumpSpace();
        let openingBracePosition = this.clonePosition();
        if (!this.bumpIf("{")) return this.error(parentArgType === "select" ? 17 : 18, createLocation(this.clonePosition(), this.clonePosition()));
        let fragmentResult = this.parseMessage(nestingLevel + 1, parentArgType, expectCloseTag);
        if (fragmentResult.err) return fragmentResult;
        let argCloseResult = this.tryParseArgumentClose(openingBracePosition);
        if (argCloseResult.err) return argCloseResult;
        options.push([selector, {
          value: fragmentResult.val,
          location: createLocation(openingBracePosition, this.clonePosition())
        }]), parsedSelectors.add(selector), this.bumpSpace(), { value: selector, location: selectorLocation } = this.parseIdentifierIfPossible();
      }
      return options.length === 0 ? this.error(parentArgType === "select" ? 15 : 16, createLocation(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !hasOtherClause ? this.error(22, createLocation(this.clonePosition(), this.clonePosition())) : {
        val: options,
        err: null
      };
    }
    tryParseDecimalInteger(expectNumberError, invalidNumberError) {
      let sign = 1, startingPosition = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (sign = -1);
      let hasDigits = !1, decimal = 0;
      for (; !this.isEOF(); ) {
        let ch = this.char();
        if (ch >= 48 && ch <= 57)
          hasDigits = !0, decimal = decimal * 10 + (ch - 48), this.bump();
        else break;
      }
      let location = createLocation(startingPosition, this.clonePosition());
      return hasDigits ? (decimal *= sign, Number.isSafeInteger(decimal) ? {
        val: decimal,
        err: null
      } : this.error(invalidNumberError, location)) : this.error(expectNumberError, location);
    }
    offset() {
      return this.position.offset;
    }
    isEOF() {
      return this.offset() === this.message.length;
    }
    clonePosition() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }
    /**
    * Return the code point at the current position of the parser.
    * Throws if the index is out of bound.
    */
    char() {
      let offset = this.position.offset;
      if (offset >= this.message.length) throw Error("out of bound");
      let code = this.message.codePointAt(offset);
      if (code === void 0) throw Error(`Offset ${offset} is at invalid UTF-16 code unit boundary`);
      return code;
    }
    error(kind, location) {
      return {
        val: null,
        err: {
          kind,
          message: this.message,
          location
        }
      };
    }
    /** Bump the parser to the next UTF-16 code unit. */
    bump() {
      if (this.isEOF()) return;
      let code = this.char();
      code === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += code < 65536 ? 1 : 2);
    }
    /**
    * If the substring starting at the current position of the parser has
    * the given prefix, then bump the parser to the character immediately
    * following the prefix and return true. Otherwise, don't bump the parser
    * and return false.
    */
    bumpIf(prefix) {
      let offset = this.offset();
      if (this.message.slice(offset, offset + prefix.length) === prefix) {
        for (let i = 0; i < prefix.length; i++) this.bump();
        return !0;
      }
      return !1;
    }
    /**
    * Bump the parser until the pattern character is found and return `true`.
    * Otherwise bump to the end of the file and return `false`.
    */
    bumpUntil(pattern) {
      let currentOffset = this.offset(), index = this.message.indexOf(pattern, currentOffset);
      return index >= 0 ? (this.bumpTo(index), !0) : (this.bumpTo(this.message.length), !1);
    }
    /**
    * Bump the parser to the target offset.
    * If target offset is beyond the end of the input, bump the parser to the end of the input.
    */
    bumpTo(targetOffset) {
      if (this.offset() > targetOffset) throw Error(`targetOffset ${targetOffset} must be greater than or equal to the current offset ${this.offset()}`);
      for (targetOffset = Math.min(targetOffset, this.message.length); ; ) {
        let offset = this.offset();
        if (offset === targetOffset) break;
        if (offset > targetOffset) throw Error(`targetOffset ${targetOffset} is at invalid UTF-16 code unit boundary`);
        if (this.bump(), this.isEOF()) break;
      }
    }
    /** advance the parser through all whitespace to the next non-whitespace code unit. */
    bumpSpace() {
      for (; !this.isEOF() && _isWhiteSpace(this.char()); ) this.bump();
    }
    /**
    * Peek at the *next* Unicode codepoint in the input without advancing the parser.
    * If the input has been exhausted, then this returns null.
    */
    peek() {
      var _a;
      if (this.isEOF()) return null;
      let code = this.char(), offset = this.offset();
      return (_a = this.message.charCodeAt(offset + (code >= 65536 ? 2 : 1))) != null ? _a : null;
    }
  };
  function _isAlpha(codepoint) {
    return codepoint >= 97 && codepoint <= 122 || codepoint >= 65 && codepoint <= 90;
  }
  function _isAlphaOrSlash(codepoint) {
    return _isAlpha(codepoint) || codepoint === 47;
  }
  function _isPotentialElementNameChar(c) {
    return c === 45 || c === 46 || c >= 48 && c <= 57 || c === 95 || c >= 97 && c <= 122 || c >= 65 && c <= 90 || c == 183 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 893 || c >= 895 && c <= 8191 || c >= 8204 && c <= 8205 || c >= 8255 && c <= 8256 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
  }
  function _isWhiteSpace(c) {
    return c >= 9 && c <= 13 || c === 32 || c === 133 || c >= 8206 && c <= 8207 || c === 8232 || c === 8233;
  }
  function pruneLocation(els) {
    els.forEach((el) => {
      if (delete el.location, isSelectElement(el) || isPluralElement(el)) for (let k in el.options)
        delete el.options[k].location, pruneLocation(el.options[k].value);
      else isNumberElement(el) && isNumberSkeleton(el.style) || (isDateElement(el) || isTimeElement(el)) && isDateTimeSkeleton(el.style) ? delete el.style.location : isTagElement(el) && pruneLocation(el.children);
    });
  }
  function parse(message, opts = {}) {
    opts = __spreadValues({
      shouldParseSkeletons: !0,
      requiresOtherClause: !0
    }, opts);
    let result = new Parser(message, opts).parse();
    if (result.err) {
      let error = SyntaxError(ErrorKind[result.err.kind]);
      throw error.location = result.err.location, error.originalMessage = result.err.message, error;
    }
    return opts != null && opts.captureLocation || pruneLocation(result.val), result.val;
  }

  // src/core/text-styles.ts
  function renderedStyles(rendered) {
    return { font: rendered.runs.some((run) => run.bold || run.italic), underline: rendered.runs.some((run) => run.underline) };
  }
  function previousStyles(advanced) {
    if (advanced != null && advanced.styleFlags) return __spreadValues({}, advanced.styleFlags);
    let styles = { font: !1, underline: !1 };
    if (!advanced) return styles;
    function visit(elements) {
      for (let element of elements)
        if (element.type === TYPE.tag)
          ["b", "strong", "i", "em"].includes(element.value) && (styles.font = !0), element.value === "u" && (styles.underline = !0), visit(element.children);
        else if (element.type === TYPE.plural || element.type === TYPE.select)
          for (let option of Object.values(element.options)) visit(option.value);
    }
    try {
      visit(parse(advanced.rawText.replace(/<br\s*\/?\s*>/gi, `
`), { shouldParseSkeletons: !1 }));
    } catch (e) {
    }
    return styles;
  }

  // src/host/text.ts
  var availableFonts;
  async function fonts() {
    return availableFonts || (availableFonts = (await figma.listAvailableFontsAsync()).map((font) => ({ family: font.fontName.family, style: font.fontName.style }))), availableFonts;
  }
  function nodeFonts(node) {
    let values = node.characters.length > 0 ? node.getRangeAllFontNames(0, node.characters.length) : typeof node.fontName != "symbol" ? [node.fontName] : [], unique = /* @__PURE__ */ new Map();
    for (let font of values) unique.set(`${font.family}\0${font.style}`, { family: font.family, style: font.style });
    return [...unique.values()];
  }
  async function missingFonts(node) {
    let missing = [];
    for (let font of nodeFonts(node))
      try {
        await figma.loadFontAsync(font);
      } catch (e) {
        missing.push(font);
      }
    return missing;
  }
  function fontVariant(base, bold, italic, choices) {
    var _a;
    let candidates = choices.filter((font) => font.family === base.family && /bold|black|heavy/i.test(font.style) === bold && /italic|oblique/i.test(font.style) === italic);
    return (_a = candidates.find((font) => /^(regular|normal|roman|book|bold|italic|bold italic)$/i.test(font.style))) != null ? _a : candidates[0];
  }
  async function prepareText(node, rendered, policy, oldStyles) {
    var _a;
    let existing = nodeFonts(node), missing = await missingFonts(node), hasFontStyles = renderedStyles(rendered).font || oldStyles.font, choices = hasFontStyles ? await fonts() : [], missingVariant = hasFontStyles && existing[0] !== void 0 && rendered.runs.some((run) => (run.bold || run.italic) && !fontVariant(existing[0], run.bold, run.italic, choices)), needsReplacement = missing.length > 0 || node.hasMissingFont || existing.length === 0 || missingVariant;
    if (needsReplacement && policy.kind === "skip") throw new NodeFailure("font-missing", "\u8BE5\u56FE\u5C42\u7F3A\u5C11\u5B57\u4F53\uFF1B\u8BF7\u5B89\u88C5\u5B57\u4F53\uFF0C\u6216\u9009\u62E9\u66FF\u4EE3\u5B57\u4F53\u540E\u91CD\u8BD5\u3002");
    let replacement = needsReplacement && policy.kind === "replace" ? policy.font : null, base = replacement != null ? replacement : existing[0];
    if (!base) throw new NodeFailure("font-missing", "\u65E0\u6CD5\u786E\u5B9A\u6587\u672C\u5B57\u4F53\uFF0C\u8BF7\u9009\u62E9\u66FF\u4EE3\u5B57\u4F53\u3002");
    if (replacement)
      try {
        await figma.loadFontAsync(replacement);
      } catch (e) {
        throw new NodeFailure("font-missing", "\u6240\u9009\u66FF\u4EE3\u5B57\u4F53\u4E0D\u53EF\u7528\uFF0C\u8BF7\u9009\u62E9\u5176\u4ED6\u5B57\u4F53\u3002");
      }
    let runFonts = [];
    for (let run of rendered.runs) {
      if (!hasFontStyles) {
        runFonts.push(null);
        continue;
      }
      let variant = (_a = fontVariant(base, run.bold, run.italic, choices)) != null ? _a : !run.bold && !run.italic ? base : void 0;
      if (!variant) throw new NodeFailure("font-missing", "\u5F53\u524D\u5B57\u4F53\u6CA1\u6709\u6240\u9700\u7684\u7C97\u4F53\u6216\u659C\u4F53\uFF0C\u8BF7\u9009\u62E9\u652F\u6301\u8BE5\u6837\u5F0F\u7684\u66FF\u4EE3\u5B57\u4F53\u3002");
      try {
        await figma.loadFontAsync(variant);
      } catch (e) {
        throw new NodeFailure("font-missing", "\u5BCC\u6587\u672C\u6240\u9700\u5B57\u4F53\u4E0D\u53EF\u7528\uFF0C\u8BF7\u9009\u62E9\u66FF\u4EE3\u5B57\u4F53\u3002");
      }
      runFonts.push(variant);
    }
    return { replacement, runFonts };
  }
  async function applyOne(page, item, language, policy, readSettings, checkCurrentPage = !0) {
    let node = await getText(page, item.nodeId);
    expectText(node, item.expectedCharacters);
    let previous = readNodeData(node.getPluginData(NODE_DATA));
    if (previous.manuallyIgnored && item.binding !== void 0) throw new NodeFailure("stale-node", "\u6587\u672C\u5DF2\u624B\u52A8\u5FFD\u7565\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u540E\u540C\u6B65\u3002");
    let oldStyles = previousStyles(previous.advanced), newStyles = renderedStyles(item.rendered), data = __spreadProps(__spreadValues({}, previous), { language, binding: item.binding === void 0 ? previous.binding : item.binding, advanced: item.rendered.advanced ? { rawText: item.rawText, renderedText: item.rendered.text, values: __spreadValues({}, item.values), styleFlags: newStyles } : null });
    if (validateBinding(data, readSettings()), JSON.stringify(copyNodeData(data)).length * 3 > 9e4) throw new NodeFailure("invalid-data", "\u6587\u672C\u7ED3\u6784\u8FC7\u5927\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u5173\u8054\u3002");
    let plan = await prepareText(node, item.rendered, policy, oldStyles);
    if (requireWrite(), checkCurrentPage && figma.currentPage.id !== page.id) throw new NodeFailure("wrong-page", "\u9884\u68C0\u671F\u95F4\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
    if (node.removed || !belongsToPage(node, page)) throw new NodeFailure("missing-node", "\u9884\u68C0\u671F\u95F4\u6587\u672C\u88AB\u79FB\u52A8\u6216\u5220\u9664\u3002");
    if (expectText(node, item.expectedCharacters), !!readNodeData(node.getPluginData(NODE_DATA)).manuallyIgnored != !!previous.manuallyIgnored) throw new NodeFailure("stale-node", "\u9884\u68C0\u671F\u95F4\u5FFD\u7565\u72B6\u6001\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
    plan.replacement && (node.fontName = plan.replacement), node.characters = item.rendered.text;
    for (let index = 0; index < item.rendered.runs.length; index += 1) {
      let run = item.rendered.runs[index], font = plan.runFonts[index];
      font && node.setRangeFontName(run.start, run.end, font), (newStyles.underline || oldStyles.underline) && node.setRangeTextDecoration(run.start, run.end, run.underline ? "UNDERLINE" : "NONE");
    }
    return writeData(node, data), node.id;
  }
  async function applyText(request, readSettings) {
    requireWrite();
    let page = await getCurrentPage(request.pageId), copy = pageCopy(page);
    if ((copy == null ? void 0 : copy.kind) === "keys") throw new Error("key \u540D\u79F0\u526F\u672C\u4E0D\u652F\u6301\u4E0B\u8F7D\u8BD1\u6587\u3002");
    if (!request.language) throw new Error("\u8BF7\u9009\u62E9\u8981\u56DE\u586B\u7684\u8BED\u8A00\u3002");
    if (copy && copy.language !== request.language) throw new Error("\u8BED\u8A00\u526F\u672C\u53EA\u80FD\u5237\u65B0\u5B83\u6240\u5BF9\u5E94\u7684\u8BED\u8A00\u3002");
    let oldLanguage = page.getPluginData(PAGE_LANGUAGE), report = { applied: [], errors: [] };
    for (let item of request.items)
      try {
        report.applied.push(await applyOne(page, item, request.language, request.fontPolicy, readSettings));
      } catch (error) {
        report.errors.push(issue(item.nodeId, error));
      }
    if (report.applied.length > 0 && figma.currentPage.id === page.id) {
      let hasUnknown = !1;
      for (let node of textNodes(page.children)) {
        let data = readNodeData(node.getPluginData(NODE_DATA));
        data.language || (oldLanguage ? writeData(node, __spreadProps(__spreadValues({}, data), { language: oldLanguage })) : hasUnknown = !0);
      }
      hasUnknown || page.setPluginData(PAGE_LANGUAGE, request.language);
    }
    return report;
  }

  // src/host/screenshots.ts
  function screenshotFrame(node) {
    let parent = node.parent, found = null;
    for (; parent && parent.type !== "PAGE" && parent.type !== "DOCUMENT"; )
      parent.type === "FRAME" && (found = parent), parent = parent.parent;
    return found;
  }
  function containsBounds(outer, inner) {
    return inner.x >= outer.x && inner.y >= outer.y && inner.x + inner.width <= outer.x + outer.width && inner.y + inner.height <= outer.y + outer.height;
  }
  function clippedByAncestor(node, area) {
    let parent = node.parent;
    for (; parent && parent.type !== "PAGE" && parent.type !== "DOCUMENT"; ) {
      if ("clipsContent" in parent && parent.clipsContent) {
        let bounds = parent.absoluteBoundingBox;
        if (!bounds || !containsBounds(bounds, area)) return !0;
      }
      parent = parent.parent;
    }
    return !1;
  }
  async function screenshots(request) {
    var _a;
    let page = await getCurrentPage(request.pageId);
    if (pageCopy(page)) throw new Error("\u9875\u9762\u526F\u672C\u4E0D\u53EF\u4E0A\u4F20\u622A\u56FE\uFF0C\u8BF7\u56DE\u5230\u539F\u9875\u9762\u3002");
    let result = { type: "screenshots", screenshots: [], errors: [] }, groups = /* @__PURE__ */ new Map();
    for (let id of request.nodeIds) {
      let stage = "text";
      try {
        let node = await getText(page, id);
        if (!node.visible || hiddenParent(node)) throw new NodeFailure("invalid-data", "\u9690\u85CF\u6587\u672C\u6216\u9690\u85CF\u7956\u5148\u4E2D\u7684\u6587\u672C\u65E0\u6CD5\u521B\u5EFA\u53EF\u89C1\u622A\u56FE\uFF0C\u8BF7\u663E\u793A\u56FE\u5C42\u540E\u91CD\u65B0\u9884\u89C8\u3002");
        stage = "frame";
        let frame = screenshotFrame(node);
        if (!frame) throw new NodeFailure("invalid-data", "\u6587\u672C\u4E0D\u5728 Frame \u4E2D\uFF0C\u65E0\u6CD5\u521B\u5EFA\u4E0A\u4E0B\u6587\u622A\u56FE\u3002");
        let group = (_a = groups.get(frame.id)) != null ? _a : { frame, nodes: [] };
        group.nodes.push(node), groups.set(frame.id, group);
      } catch (error) {
        result.errors.push(issue(id, error, stage === "text" ? "\u8BFB\u53D6\u622A\u56FE\u6587\u672C\u56FE\u5C42\u5931\u8D25\uFF0C\u8BF7\u5173\u95ED\u5E76\u91CD\u65B0\u6253\u5F00\u63D2\u4EF6\u540E\u91CD\u8BD5\u3002" : "\u67E5\u627E\u622A\u56FE\u753B\u677F\u5931\u8D25\uFF0C\u8BF7\u5173\u95ED\u5E76\u91CD\u65B0\u6253\u5F00\u63D2\u4EF6\u540E\u91CD\u8BD5\u3002"));
      }
    }
    for (let { frame, nodes } of groups.values())
      try {
        let bounds = frame.absoluteBoundingBox;
        if (!bounds) throw new Error("No bounds");
        let scale = Math.min(1, 2048 / Math.max(bounds.width, bounds.height)), width = Math.round(bounds.width * scale), height = Math.round(bounds.height * scale), regions = [];
        for (let node of nodes) {
          let area = node.absoluteBoundingBox;
          if (!area || ![area.x, area.y, area.width, area.height].every(Number.isFinite) || area.width <= 0 || area.height <= 0) {
            result.errors.push({ nodeId: node.id, code: "invalid-data", message: "\u65E0\u6CD5\u8BFB\u53D6\u5B8C\u6574\u6587\u672C\u8FB9\u754C\uFF0C\u8BF7\u8C03\u6574 Frame \u6216\u9009\u533A\u540E\u91CD\u65B0\u9884\u89C8\u3002" });
            continue;
          }
          if (!containsBounds(bounds, area)) {
            result.errors.push({ nodeId: node.id, code: "invalid-data", message: "\u6587\u672C\u8FB9\u754C\u8D85\u51FA\u622A\u56FE\u753B\u677F\uFF0C\u8BF7\u8C03\u6574 Frame \u6216\u9009\u533A\u540E\u91CD\u65B0\u9884\u89C8\u3002" });
            continue;
          }
          if (clippedByAncestor(node, area)) {
            result.errors.push({ nodeId: node.id, code: "invalid-data", message: "\u6587\u672C\u88AB\u4E0A\u5C42\u5BB9\u5668\u88C1\u526A\uFF0C\u8BF7\u8C03\u6574 Frame \u6216\u9009\u533A\u540E\u91CD\u65B0\u9884\u89C8\u3002" });
            continue;
          }
          regions.push({ nodeId: node.id, x: (area.x - bounds.x) * scale, y: (area.y - bounds.y) * scale, width: area.width * scale, height: area.height * scale, absoluteBounds: { x: area.x, y: area.y, width: area.width, height: area.height } });
        }
        if (!regions.length) continue;
        let bytes = await frame.exportAsync({ format: "PNG", useAbsoluteBounds: !0, constraint: { type: "SCALE", value: scale } });
        result.screenshots.push({ frameId: frame.id, name: frame.name, width, height, bytes: Array.from(bytes), nodes: regions });
      } catch (e) {
        for (let node of nodes) result.errors.some((error) => error.nodeId === node.id) || result.errors.push({ nodeId: node.id, code: "unknown", message: "\u6240\u5728 Frame \u622A\u56FE\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u5C3A\u5BF8\u4E0E\u56FE\u5C42\u5185\u5BB9\u3002" });
      }
    return result;
  }

  // src/host/page-copies.ts
  async function managedCopies(source, kind, language, target) {
    let result = [];
    for (let page of figma.root.children) {
      if (page.id === source.id) continue;
      await page.loadAsync();
      let copy = pageCopy(page);
      copy != null && copy.target && copy.sourcePageId === source.id && copy.kind === kind && (kind === "keys" || copy.language === language) && sameTarget(copy.target, target) && result.push(page);
    }
    return result;
  }
  async function previewCopy(request, readSettings, readRecords) {
    var _a;
    requireWrite();
    let source = await getPage(request.sourcePageId);
    if (pageCopy(source)) throw new Error("\u8BF7\u4ECE\u539F\u9875\u9762\u521B\u5EFA\u526F\u672C\u3002");
    let config = readSettings();
    if (!sameTarget(request.target, config)) throw new Error("\u9879\u76EE\u6216\u5206\u652F\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u9875\u9762\u526F\u672C\u3002");
    let replacements = [];
    for (let page of await managedCopies(source, request.kind, request.language, request.target)) {
      let fingerprint = await pageFingerprint(page);
      replacements.push({ pageId: page.id, name: page.name, fingerprint, modified: ((_a = pageCopy(page)) == null ? void 0 : _a.contentFingerprint) !== fingerprint });
    }
    return { type: "copy-preview", source: pageRecord(source), nodes: readRecords(source, source.children, config).filter((node) => !node.manuallyIgnored), sourceFingerprint: await pageFingerprint(source), replacements };
  }
  async function createCopy(request, previousPageId, readSettings, readRecords) {
    var _a, _b, _c, _d, _e, _f;
    requireWrite();
    let source = await getPage(request.sourcePageId);
    if (pageCopy(source)) throw new Error("\u8BF7\u4ECE\u539F\u9875\u9762\u521B\u5EFA\u526F\u672C\u3002");
    let config = readSettings();
    if (!sameTarget(request.target, config)) throw new Error("\u9879\u76EE\u6216\u5206\u652F\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u9875\u9762\u526F\u672C\u3002");
    if (await pageFingerprint(source) !== request.sourceFingerprint) throw new Error("\u539F\u9875\u9762\u7684\u5185\u5BB9\u6216\u5173\u8054\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u540E\u521B\u5EFA\u526F\u672C\u3002");
    if (request.kind === "language" && !request.language) throw new Error("\u8BF7\u9009\u62E9\u526F\u672C\u8BED\u8A00\u3002");
    let previous = await managedCopies(source, request.kind, request.language, request.target);
    if (previous.length !== request.replacements.length || previous.some((page) => !request.replacements.some((item) => item.pageId === page.id))) throw new Error("\u53D7\u7BA1\u526F\u672C\u5217\u8868\u5DF2\u7ECF\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u66FF\u6362\u8303\u56F4\u3002");
    if (previousPageId && !previous.some((page) => page.id === previousPageId)) throw new Error("\u65E7\u526F\u672C\u7F3A\u5C11\u5B8C\u6574\u6765\u6E90\u6216\u76EE\u6807\u4FE1\u606F\uFF0C\u4E0D\u80FD\u5B89\u5168\u66FF\u6362\uFF1B\u8BF7\u56DE\u5230\u539F\u9875\u9762\u91CD\u65B0\u521B\u5EFA\u3002");
    for (let page of previous) {
      let expected = request.replacements.find((item) => item.pageId === page.id);
      if (!expected || await pageFingerprint(page) !== expected.fingerprint) throw new Error("\u5F85\u66FF\u6362\u526F\u672C\u5728\u9884\u89C8\u540E\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
    }
    let copy = source.clone(), replacementStarted = !1;
    try {
      let originalNodes = textNodes(source.children), sourceRecords = new Map(readRecords(source, source.children, config).filter((node) => !node.manuallyIgnored).map((node) => [node.id, node])), translations = new Map(request.translations.map((translation) => [translation.nodeId, translation]));
      copy.name = (_b = (_a = previous[0]) == null ? void 0 : _a.name) != null ? _b : `${source.name} \xB7 ${request.kind === "keys" ? "Keys" : request.language}`;
      let metadata = { kind: request.kind, sourcePageId: source.id, sourceFingerprint: request.sourceFingerprint, language: request.kind === "keys" ? "" : request.language, createdAt: (/* @__PURE__ */ new Date()).toISOString(), target: { serverUrl: request.target.serverUrl, projectId: request.target.projectId, branchId: request.target.branchId } };
      copy.setPluginData(PAGE_COPY, JSON.stringify(metadata)), copy.setPluginData(PAGE_LANGUAGE, source.getPluginData(PAGE_LANGUAGE));
      let clonedNodes = textNodes(copy.children), paired = clonedTexts(source, copy), report = { applied: [], errors: [] };
      for (let original of originalNodes) {
        let node = paired.get(original.id);
        if (!node) {
          report.errors.push({ nodeId: original.id, code: "invalid-data", message: "\u590D\u5236\u540E\u7684\u7EC4\u4EF6\u7ED3\u6784\u4E0E\u539F\u8282\u70B9\u4E0D\u4E00\u81F4\uFF0C\u8BE5\u6587\u672C\u672A\u56DE\u586B\u3002" });
          continue;
        }
        let data = (_c = sourceRecords.get(original.id)) != null ? _c : readNodeData(original.getPluginData(NODE_DATA));
        try {
          if (writeData(node, __spreadProps(__spreadValues({}, data), { language: data.language || source.getPluginData(PAGE_LANGUAGE) })), !sourceRecords.has(original.id)) continue;
          if (request.kind === "keys") {
            let keyName = ((_d = data.binding) == null ? void 0 : _d.keyName) || data.keyName;
            if (!keyName) continue;
            let rendered = { text: keyName, advanced: !1, runs: keyName ? [{ start: 0, end: keyName.length, bold: !1, italic: !1, underline: !1 }] : [] };
            report.applied.push(await applyOne(copy, { nodeId: node.id, expectedCharacters: node.characters, rawText: keyName, values: {}, rendered }, data.language || source.getPluginData(PAGE_LANGUAGE), request.fontPolicy, readSettings, !1));
          } else {
            let translation = translations.get(original.id);
            if (!translation || !data.binding || !sameTarget(data.binding, request.target) || translation.keyId !== data.binding.keyId || translation.keyName !== data.binding.keyName || translation.namespace !== data.binding.namespace) throw new NodeFailure("invalid-data", "\u8BE5\u6587\u672C\u6CA1\u6709\u5339\u914D\u8BD1\u6587\uFF0C\u526F\u672C\u4FDD\u7559\u539F\u6587\u3002");
            let binding = __spreadProps(__spreadValues({}, data.binding), { baselines: __spreadProps(__spreadValues({}, data.binding.baselines), { [request.language]: translation.rawText }) });
            report.applied.push(await applyOne(copy, { nodeId: node.id, expectedCharacters: node.characters, rawText: translation.rawText, values: translation.values, rendered: translation.rendered, binding }, request.language, request.fontPolicy, readSettings, !1));
          }
        } catch (error) {
          report.errors.push(issue(node.id, error));
        }
      }
      if (request.kind === "language" && clonedNodes.every((node) => readNodeData(node.getPluginData(NODE_DATA)).language !== "") && copy.setPluginData(PAGE_LANGUAGE, request.language), previous.length && report.errors.length) throw new Error("\u65B0\u526F\u672C\u672A\u80FD\u5B8C\u6574\u56DE\u586B\uFF0C\u5DF2\u4FDD\u7559\u65E7\u526F\u672C\uFF1B\u8BF7\u5904\u7406\u7F3A\u5931\u8BD1\u6587\u6216\u5B57\u4F53\u540E\u91CD\u8BD5\u3002");
      if (metadata.contentFingerprint = await pageFingerprint(copy), copy.setPluginData(PAGE_COPY, JSON.stringify(metadata)), await figma.setCurrentPageAsync(copy), !sameTarget(request.target, readSettings()) || await pageFingerprint(source) !== request.sourceFingerprint) throw new Error("\u521B\u5EFA\u671F\u95F4\u539F\u9875\u9762\u6216\u8FDE\u63A5\u76EE\u6807\u53D1\u751F\u53D8\u5316\uFF0C\u5DF2\u4FDD\u7559\u65E7\u526F\u672C\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
      for (let page of previous) {
        let expected = request.replacements.find((item) => item.pageId === page.id);
        if (!expected || await pageFingerprint(page) !== expected.fingerprint) throw new Error("\u521B\u5EFA\u671F\u95F4\u65E7\u526F\u672C\u5DF2\u88AB\u4FEE\u6539\uFF0C\u5DF2\u4FDD\u7559\u65E7\u526F\u672C\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
      }
      replacementStarted = !0;
      for (let page of previous)
        try {
          page.remove();
        } catch (e) {
          report.errors.push({ nodeId: page.id, code: "unknown", message: "\u65B0\u526F\u672C\u5DF2\u521B\u5EFA\uFF0C\u4F46\u65E7\u526F\u672C\u672A\u80FD\u79FB\u9664\uFF0C\u8BF7\u68C0\u67E5\u9875\u9762\u5217\u8868\u3002" });
        }
      return { type: "page-copy", page: pageRecord(copy), report, previousPageId: (_f = (_e = previous[0]) == null ? void 0 : _e.id) != null ? _f : null };
    } catch (error) {
      throw replacementStarted || (figma.currentPage.id === copy.id && await figma.setCurrentPageAsync(source), copy.remove()), error;
    }
  }

  // src/main.ts
  var SETTINGS = "lingora.settings.v1", DEVICE_CONNECTION = "lingora.connection.v1", scanScope = "selection", generation = 0, timer, sessionSettings, watchedPage, queue = Promise.resolve(), sessionNonce, cachedPageId = "", cachedScanKey = "", cachedRecords = /* @__PURE__ */ new Map(), cachedOrder = /* @__PURE__ */ new Set(), cachedAncestors = /* @__PURE__ */ new Map(), cachedNodeAncestors = /* @__PURE__ */ new Map(), copyStatus, windowLimit = { width: null, height: null };
  function send(message) {
    sessionNonce && figma.ui.postMessage(__spreadProps(__spreadValues({}, message), { sessionNonce }));
  }
  function cleanDeviceConnection(value) {
    return { serverUrl: value.serverUrl, projectId: value.projectId, apiKey: value.apiKey };
  }
  function settings() {
    if (sessionSettings) return cleanSettings(sessionSettings);
    try {
      let value = JSON.parse(figma.root.getPluginData(SETTINGS));
      return isSettings(value) ? cleanSettings(value) : cleanSettings(DEFAULT_SETTINGS);
    } catch (e) {
      return cleanSettings(DEFAULT_SETTINGS);
    }
  }
  function cleanSettings(value) {
    var _a, _b;
    return { serverUrl: value.serverUrl, projectId: value.projectId, branchId: value.branchId, namespace: value.namespace, keyTemplate: value.keyTemplate, keyCase: value.keyCase, prefillKeys: value.prefillKeys, showIgnored: (_a = value.showIgnored) != null ? _a : !1, ignore: { numbers: value.ignore.numbers, formattedNumbers: value.ignore.formattedNumbers, emoji: (_b = value.ignore.emoji) != null ? _b : !0, hiddenLayers: value.ignore.hiddenLayers, hiddenChildren: value.ignore.hiddenChildren, prefix: value.ignore.prefix }, uploadScreenshots: value.uploadScreenshots, tags: [...value.tags] };
  }
  function namingFields(node) {
    let fields = { elementName: node.name, elementText: node.characters, frame: "", artboard: "", group: "", component: "", instance: "", section: "" }, parent = node.parent;
    for (; parent && parent.type !== "PAGE" && parent.type !== "DOCUMENT"; )
      parent.type === "FRAME" && (fields.frame || (fields.frame = parent.name), fields.artboard = parent.name), parent.type === "GROUP" && !fields.group && (fields.group = parent.name), parent.type === "COMPONENT" && !fields.component && (fields.component = parent.name), parent.type === "INSTANCE" && !fields.instance && (fields.instance = parent.name), parent.type === "SECTION" && !fields.section && (fields.section = parent.name), parent = parent.parent;
    return fields;
  }
  function records(page, roots, config) {
    let selection = new Set(page.selection.map((node) => node.id));
    return textNodes(roots).filter((node) => !shouldIgnoreText(node.characters, node.name, node.visible, hiddenParent(node), config.ignore)).map((node) => {
      let data = readNodeData(node.getPluginData(NODE_DATA)), fields = namingFields(node);
      return !data.binding && !data.keyName && !data.keyNameCleared && config.prefillKeys && (data.keyName = generateKey(config.keyTemplate, fields, config.keyCase), data.namespace = data.namespace || config.namespace), __spreadProps(__spreadValues({}, data), { language: data.language || page.getPluginData(PAGE_LANGUAGE), id: node.id, name: node.name, characters: node.characters, fields, selected: insideRoots(node, selection), advancedDrift: data.advanced !== null && data.advanced.renderedText !== node.characters });
    }).filter((node) => config.showIgnored || !node.manuallyIgnored);
  }
  function cacheRecords(page, roots, config) {
    var _a;
    let nodes = records(page, roots, config);
    for (let record of nodes)
      cachedRecords.set(record.id, record), cachedOrder.add(record.id);
    for (let node of textNodes(roots)) {
      let ancestors = [], current = node;
      for (; current && current.type !== "PAGE" && current.type !== "DOCUMENT"; ) {
        let ids = (_a = cachedAncestors.get(current.id)) != null ? _a : /* @__PURE__ */ new Set();
        ids.add(node.id), cachedAncestors.set(current.id, ids), ancestors.push(current.id), current = current.parent;
      }
      cachedNodeAncestors.set(node.id, ancestors);
    }
  }
  function evictCached(id) {
    var _a, _b;
    for (let child of [...(_a = cachedAncestors.get(id)) != null ? _a : [id]]) {
      cachedRecords.delete(child);
      for (let ancestor of (_b = cachedNodeAncestors.get(child)) != null ? _b : []) {
        let ids = cachedAncestors.get(ancestor);
        ids == null || ids.delete(child), (ids == null ? void 0 : ids.size) === 0 && cachedAncestors.delete(ancestor);
      }
      cachedNodeAncestors.delete(child);
    }
  }
  function insideRoots(node, ids) {
    let current = node;
    for (; current && current.type !== "PAGE"; ) {
      if (ids.has(current.id)) return !0;
      current = current.parent;
    }
    return !1;
  }
  function handleNodeChange(event) {
    var _a;
    let page = figma.currentPage;
    if (cachedPageId === page.id) {
      let config = settings(), roots = scanScope === "selection" && page.selection.length ? page.selection : page.children, rootIds = new Set(roots.map((root) => root.id)), changedRoots = /* @__PURE__ */ new Map();
      for (let change of event.nodeChanges) {
        if (change.type === "PROPERTY_CHANGE" && !change.properties.some((property) => ["name", "characters", "text", "visible", "parent", "pluginData", "componentProperties", "componentPropertyReferences", "componentPropertyDefinitions", "mainComponent"].includes(property))) continue;
        if (change.type === "DELETE") for (let id of (_a = cachedAncestors.get(change.id)) != null ? _a : [change.id]) cachedOrder.delete(id);
        if (evictCached(change.id), change.node.removed) continue;
        let node = change.node;
        if (insideRoots(node, rootIds)) changedRoots.set(node.id, node);
        else for (let root of roots)
          belongsToAncestor(root, node) && changedRoots.set(root.id, root);
      }
      changedRoots.size && cacheRecords(page, [...changedRoots.values()], config);
    }
    scheduleSnapshot(!1);
  }
  function belongsToAncestor(node, ancestor) {
    let current = node;
    for (; current && current.type !== "PAGE"; ) {
      if (current.id === ancestor.id) return !0;
      current = current.parent;
    }
    return !1;
  }
  function currentFileKey() {
    try {
      let key = figma.fileKey;
      return isFigmaFileKey(key) ? key : null;
    } catch (e) {
      return null;
    }
  }
  async function snapshot(refresh = !0, includeFingerprint = !1) {
    var _a, _b;
    requirePluginIdentity();
    let page = figma.currentPage, config = settings(), currentPage = pageRecord(page), scope = scanScope === "selection" && page.selection.length > 0 ? "selection" : "page", roots = scope === "selection" ? page.selection : page.children, key = JSON.stringify([page.id, scope, scope === "selection" ? roots.map((node) => node.id) : [], config, currentPage.language]);
    if ((refresh || cachedPageId !== page.id || cachedScanKey !== key) && (cachedRecords.clear(), cachedOrder.clear(), cachedAncestors.clear(), cachedNodeAncestors.clear(), cachedPageId = page.id, cachedScanKey = key, cacheRecords(page, roots, config)), currentPage.copy && (refresh || (copyStatus == null ? void 0 : copyStatus.pageId) !== page.id))
      try {
        let source = await getPage(currentPage.copy.sourcePageId), fingerprint = currentPage.copy.target ? await pageFingerprint(source) : bindingFingerprint(records(source, source.children, config));
        copyStatus = { pageId: page.id, stale: fingerprint !== currentPage.copy.sourceFingerprint, missing: !1 };
      } catch (e) {
        copyStatus = { pageId: page.id, stale: !0, missing: !0 };
      }
    return { fileName: figma.root.name, fileKey: currentFileKey(), editorType: figma.editorType === "dev" ? "dev" : "figma", devMode: figma.editorType !== "figma", currentPage, pages: figma.root.children.map(pageRecord), nodes: [...cachedOrder].flatMap((id) => {
      let node = cachedRecords.get(id);
      return node ? [node] : [];
    }), selectionIds: page.selection.map((node) => node.id), scope, settings: config, pageFingerprint: includeFingerprint ? await pageFingerprint(page) : "", copyStale: currentPage.copy && (_a = copyStatus == null ? void 0 : copyStatus.stale) != null ? _a : !1, sourceMissing: currentPage.copy && (_b = copyStatus == null ? void 0 : copyStatus.missing) != null ? _b : !1 };
  }
  function requirePluginIdentity() {
    var _a;
    if (!((_a = figma.pluginId) != null && _a.trim())) throw new Error("\u63D2\u4EF6\u5C1A\u672A\u914D\u7F6E Figma ID\u3002\u8BF7\u5148\u901A\u8FC7 Figma \u7684 Plugins \u2192 Development \u2192 New Plugin \u521B\u5EFA\u63D2\u4EF6\u53D6\u5F97 ID\uFF0C\u518D\u6309 README \u914D\u7F6E\u5E76\u91CD\u65B0\u6784\u5EFA\u3001\u5BFC\u5165\u3002");
  }
  function scheduleSnapshot(refresh = !1) {
    generation += 1;
    let version = generation;
    timer !== void 0 && clearTimeout(timer), timer = setTimeout(() => {
      snapshot(refresh).then((value) => {
        version === generation && send({ type: "snapshot", snapshot: value });
      }).catch(() => {
        console.warn("lingora_main_snapshot_failed");
      });
    }, 100);
  }
  async function saveNodes(request) {
    requireWrite();
    let page = await getCurrentPage(request.pageId);
    if (pageCopy(page)) throw new Error("\u9875\u9762\u526F\u672C\u4EC5\u4F9B\u67E5\u770B\uFF0C\u8BF7\u56DE\u5230\u539F\u9875\u9762\u7F16\u8F91\u5173\u8054\u3002");
    let config = settings(), report = { applied: [], errors: [] };
    for (let item of request.items)
      try {
        let node = await getText(page, item.nodeId);
        if (figma.currentPage.id !== page.id) throw new NodeFailure("wrong-page", "\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF\u540E\u64CD\u4F5C\u3002");
        expectText(node, item.expectedCharacters), validateBinding(item.data, config), writeData(node, item.data), report.applied.push(node.id);
      } catch (error) {
        report.errors.push(issue(item.nodeId, error));
      }
    return report;
  }
  async function setNodeIgnored(request) {
    requireWrite();
    let page = await getCurrentPage(request.pageId);
    if (pageCopy(page)) throw new Error("\u9875\u9762\u526F\u672C\u4EC5\u4F9B\u67E5\u770B\uFF0C\u8BF7\u56DE\u5230\u539F\u9875\u9762\u7BA1\u7406\u5FFD\u7565\u72B6\u6001\u3002");
    let report = { applied: [], errors: [] };
    for (let item of request.items)
      try {
        let node = await getText(page, item.nodeId);
        if (figma.currentPage.id !== page.id) throw new NodeFailure("wrong-page", "\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF\u540E\u64CD\u4F5C\u3002");
        expectText(node, item.expectedCharacters), writeData(node, __spreadProps(__spreadValues({}, readNodeData(node.getPluginData(NODE_DATA))), { manuallyIgnored: request.ignored })), report.applied.push(node.id);
      } catch (error) {
        report.errors.push(issue(item.nodeId, error));
      }
    return report;
  }
  function openKey(request) {
    let config = settings();
    if (!sameTarget(request.target, config)) throw new Error("\u8FDE\u63A5\u76EE\u6807\u5DF2\u7ECF\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u8BCD\u6761\u3002");
    let server = config.serverUrl.replace(/\/$/, ""), secure = /^https:\/\/(?:[a-z0-9.-]+|\[[0-9a-f:]+\])(?::\d{1,5})?$/i.test(server), local = /^http:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d{1,5})?$/i.test(server), uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!secure && !local || !uuid.test(config.projectId) || !uuid.test(config.branchId)) throw new Error("\u5F53\u524D\u670D\u52A1\u6216\u9879\u76EE\u5730\u5740\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5 Lingora\u3002");
    figma.openExternal(`${server}/projects/${config.projectId}/translations?branchId=${encodeURIComponent(config.branchId)}&q=${encodeURIComponent(request.keyName)}`);
  }
  function resizeWindow(request) {
    if (request.measure) {
      windowLimit = { width: null, height: null };
      let fitted = expandPluginWindowToHostLimit();
      return insetPluginWindowEvenly(fitted), windowLimit = { width: fitted.width < 1e5 ? fitted.width : null, height: fitted.height < 1e5 ? fitted.height : null }, { type: "ok" };
    }
    let desired = clampPluginWindow({ width: request.width, height: request.height }, null), attempt = clampPluginWindow(desired, windowLimit);
    try {
      figma.ui.resize(attempt.width, attempt.height);
    } catch (error) {
      windowLimit = { width: null, height: null };
      let fitted = fitPluginWindow(attempt, (size) => figma.ui.resize(size.width, size.height), error);
      windowLimit = { width: fitted.width < attempt.width ? fitted.width : null, height: fitted.height < attempt.height ? fitted.height : null };
    }
    return { type: "ok" };
  }
  function expandPluginWindowToHostLimit() {
    anchorPluginWindow();
    let desired = clampPluginWindow({ width: 1e5, height: 1e5 }, null);
    try {
      return figma.ui.resize(desired.width, desired.height), desired;
    } catch (error) {
      return fitPluginWindow(desired, (size) => figma.ui.resize(size.width, size.height), error);
    }
  }
  function insetPluginWindowEvenly(fitted) {
    let placement = readPluginWindowPlacement();
    if (!placement) return;
    let balanced = balancePluginWindow({ x: placement.windowSpace.x, y: placement.windowSpace.y, width: fitted.width, height: fitted.height }, 32);
    (balanced.size.width !== fitted.width || balanced.size.height !== fitted.height) && figma.ui.resize(balanced.size.width, balanced.size.height), placePluginWindow(balanced.origin);
  }
  function anchorPluginWindow() {
    try {
      placePluginWindow({ x: 0, y: 0 });
    } catch (e) {
    }
  }
  function placePluginWindow(targetWindow) {
    var _a;
    let before = readPluginWindowPlacement(), canvas = pluginWindowTarget(before, targetWindow);
    if (!canvas) return;
    figma.ui.reposition(canvas.x, canvas.y);
    let after = readPluginWindowPlacement();
    if (pluginWindowMovedToward(before, after, targetWindow)) return;
    if (before && after && Math.hypot(after.windowSpace.x - before.windowSpace.x, after.windowSpace.y - before.windowSpace.y) > 1) {
      figma.ui.reposition(before.canvasSpace.x, before.canvasSpace.y);
      return;
    }
    figma.ui.hide(), figma.ui.show();
    let retry = pluginWindowTarget((_a = readPluginWindowPlacement()) != null ? _a : before, targetWindow);
    retry && figma.ui.reposition(retry.x, retry.y);
  }
  function pluginWindowTarget(current, targetWindow) {
    if (current) return pluginWindowCanvasPoint(current, targetWindow, figma.viewport.zoom);
    let bounds = figma.viewport.bounds;
    return Number.isFinite(bounds.x) && Number.isFinite(bounds.y) ? { x: bounds.x, y: bounds.y } : null;
  }
  function readPluginWindowPlacement() {
    try {
      let position = figma.ui.getPosition(), placement = { windowSpace: { x: position.windowSpace.x, y: position.windowSpace.y }, canvasSpace: { x: position.canvasSpace.x, y: position.canvasSpace.y } };
      return [placement.windowSpace.x, placement.windowSpace.y, placement.canvasSpace.x, placement.canvasSpace.y].every(Number.isFinite) ? placement : null;
    } catch (e) {
      return null;
    }
  }
  async function execute(request) {
    var _a;
    switch (request.type) {
      case "scan":
        return scanScope = (_a = request.scope) != null ? _a : scanScope, { type: "snapshot", snapshot: await snapshot(!0, request.includeFingerprint) };
      case "save-settings": {
        let clean = cleanSettings(request.settings);
        return figma.editorType === "dev" ? sessionSettings = clean : (requireWrite(), figma.root.setPluginData(SETTINGS, JSON.stringify(clean)), sessionSettings = void 0), { type: "ok" };
      }
      case "load-device-connection": {
        let saved;
        try {
          saved = await figma.clientStorage.getAsync(DEVICE_CONNECTION);
        } catch (e) {
          throw new Error("\u65E0\u6CD5\u8BFB\u53D6\u6B64\u8BBE\u5907\u8BB0\u4F4F\u7684\u8FDE\u63A5\uFF0C\u8BF7\u624B\u52A8\u8FDE\u63A5\u540E\u91CD\u8BD5\u3002");
        }
        if (saved == null) return { type: "device-connection", connection: null };
        if (!isDeviceConnection(saved)) throw new Error("\u6B64\u8BBE\u5907\u8BB0\u4F4F\u7684\u8FDE\u63A5\u65E0\u6548\uFF0C\u8BF7\u6E05\u9664\u540E\u91CD\u65B0\u8FDE\u63A5\u3002");
        return { type: "device-connection", connection: cleanDeviceConnection(saved) };
      }
      case "save-device-connection": {
        try {
          await figma.clientStorage.setAsync(DEVICE_CONNECTION, cleanDeviceConnection(request.connection));
        } catch (e) {
          throw new Error("\u8FDE\u63A5\u53EF\u7EE7\u7EED\u4F7F\u7528\uFF0C\u4F46\u672A\u80FD\u8BB0\u4F4F\u5230\u6B64\u8BBE\u5907\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002");
        }
        return { type: "ok" };
      }
      case "forget-device-connection": {
        try {
          await figma.clientStorage.deleteAsync(DEVICE_CONNECTION);
        } catch (e) {
          throw new Error("\u672A\u80FD\u6E05\u9664\u6B64\u8BBE\u5907\u8BB0\u4F4F\u7684\u8FDE\u63A5\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002");
        }
        return { type: "ok" };
      }
      case "set-page-language": {
        requireWrite();
        let page = await getCurrentPage(request.pageId);
        if (pageCopy(page)) throw new Error("\u526F\u672C\u8BED\u8A00\u7531\u5176\u7C7B\u578B\u51B3\u5B9A\uFF0C\u4E0D\u80FD\u76F4\u63A5\u4FEE\u6539\u3002");
        if (!request.language.trim()) throw new Error("\u8BF7\u9009\u62E9\u9875\u9762\u6587\u6848\u8BED\u8A00\u3002");
        let oldLanguage = page.getPluginData(PAGE_LANGUAGE);
        if (oldLanguage && oldLanguage !== request.language)
          for (let node of textNodes(page.children)) {
            let data = readNodeData(node.getPluginData(NODE_DATA));
            data.language || writeData(node, __spreadProps(__spreadValues({}, data), { language: oldLanguage }));
          }
        return page.setPluginData(PAGE_LANGUAGE, request.language), { type: "ok" };
      }
      case "set-node-ignored":
        return { type: "mutation", report: await setNodeIgnored(request) };
      case "save-nodes":
        return { type: "mutation", report: await saveNodes(request) };
      case "font-check": {
        let current = figma.currentPage, copy = pageCopy(current);
        if (request.pageId !== current.id && (!(copy != null && copy.target) || !sameTarget(copy.target, settings()) || copy.sourcePageId !== request.pageId)) throw new Error("\u5B57\u4F53\u68C0\u67E5\u9875\u9762\u4E0D\u5C5E\u4E8E\u5F53\u524D\u9875\u9762\u6216\u5176\u53D7\u7BA1\u539F\u9875\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
        let page = await getPage(request.pageId);
        if (figma.currentPage.id !== current.id) throw new Error("\u52A0\u8F7D\u671F\u95F4\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u3002");
        let checks = { type: "font-check", fonts: [], errors: [] };
        for (let id of request.nodeIds)
          try {
            let node = await getText(page, id);
            checks.fonts.push({ nodeId: id, missing: await missingFonts(node), hasMissingFont: node.hasMissingFont });
          } catch (error) {
            checks.errors.push(issue(id, error));
          }
        return checks;
      }
      case "list-fonts":
        return { type: "fonts", fonts: await fonts() };
      case "apply-text":
        return { type: "mutation", report: await applyText(request, settings) };
      case "screenshots":
        return screenshots(request);
      case "preview-copy":
        return previewCopy(request, settings, records);
      case "create-copy":
        return createCopy(request.copy, null, settings, records);
      case "rebuild-copy":
        return createCopy(request.copy, request.pageId, settings, records);
      case "focus": {
        let nodes = [];
        for (let id of request.nodeIds) {
          let node = await getText(figma.currentPage, id);
          nodes.push(node);
        }
        return nodes.length > 0 && figma.viewport.scrollAndZoomIntoView(nodes), { type: "ok" };
      }
      case "open-page":
        return await figma.setCurrentPageAsync(await getPage(request.pageId)), { type: "ok" };
      case "open-key":
        return openKey(request), { type: "ok" };
      case "resize":
        return resizeWindow(request);
    }
  }
  figma.showUI(__html__, { width: 500, height: 600, themeColors: !0 });
  figma.ui.onmessage = (raw) => {
    if (!isMainRequest(raw)) {
      if (!sessionNonce || !isObject(raw) || raw.sessionNonce !== sessionNonce) return;
      let requestId = isObject(raw) && typeof raw.requestId == "string" ? raw.requestId.slice(0, 200) : "";
      send({ type: "error", requestId, message: "\u63D2\u4EF6\u6D88\u606F\u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u63D2\u4EF6\u3002" });
      return;
    }
    if (sessionNonce) {
      if (raw.sessionNonce !== sessionNonce) return;
    } else {
      if (raw.type !== "scan") return;
      sessionNonce = raw.sessionNonce;
    }
    if (raw.type === "resize") {
      try {
        send({ type: "result", requestId: raw.requestId, result: resizeWindow(raw) });
      } catch (error) {
        send({ type: "error", requestId: raw.requestId, message: error instanceof Error && !(error instanceof TypeError) ? error.message : "\u65E0\u6CD5\u8C03\u6574\u63D2\u4EF6\u7A97\u53E3\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002" });
      }
      return;
    }
    queue = queue.then(async () => {
      try {
        send({ type: "result", requestId: raw.requestId, result: await execute(raw) });
      } catch (error) {
        send({ type: "error", requestId: raw.requestId, message: error instanceof Error && !(error instanceof TypeError) ? error.message : "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF\u540E\u91CD\u8BD5\u3002" });
      }
      ["save-settings", "set-page-language", "save-nodes", "apply-text", "create-copy", "rebuild-copy", "open-page"].includes(raw.type) && scheduleSnapshot(!0);
    });
  };
  function watchCurrentPage() {
    watchedPage && !watchedPage.removed && watchedPage.off("nodechange", handleNodeChange), watchedPage = figma.currentPage, watchedPage.on("nodechange", handleNodeChange), scheduleSnapshot();
  }
  figma.on("selectionchange", () => scheduleSnapshot(!0));
  figma.on("currentpagechange", watchCurrentPage);
  watchCurrentPage();
  scheduleSnapshot();
})();
